#include <stdio.h>
#include <iostream>
#include <unordered_set>
using namespace std;

char G[4][5];
int M, N, A, B, C;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    cin >> M >> N >> A >> B >> C;
    for (int i = 0; i < M; i ++) {
        cin >> G[i];
    }

    

    return 0;
}