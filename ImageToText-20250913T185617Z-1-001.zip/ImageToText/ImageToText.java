import java.io.File;
import java.awt.Image;
// import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.TextAttribute;
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.text.AttributeSet.FontAttribute;

public class ImageToText {

    static ImageToText ITT;

    JFrame frame;
    JPanel panel;
    JPanel inputPanel;
    JTextField pathField;
    TextPrompt pathPrompt;
    JButton browse;
    JFileChooser fileChooser;
    JLabel scaleLabel;
    JTextField scaleField;
    JButton transform;
    // JTextArea textArea;
    // JTextPane textPane;
    // JPanel textPanel;
    TextPanel textPanel;
    int widthShown;
    int heightShown;

    ImageToText() throws Exception {
        System.out.println("Opening Window...");

        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

        frame = new JFrame("Image to Text");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setOpaque(true);
        // panel.setLayout(new GridBagLayout());
        panel.setLayout(new BorderLayout(3, 2));
        // panel.setSize(new Dimension(600, 600));

        inputPanel = new JPanel();
        inputPanel.setOpaque(true);

        pathField = new JTextField(35);
        pathPrompt = new TextPrompt("Enter Path", pathField);
        inputPanel.add(pathField, BorderLayout.PAGE_START);

        browse = new JButton("Browse");
        fileChooser = new JFileChooser(FileSystemView.getFileSystemView());
        FileNameExtensionFilter restrict = new FileNameExtensionFilter("Only Image files", "jpg", "png", "gif", "jpeg");
        fileChooser.addChoosableFileFilter(restrict);
        fileChooser.setAcceptAllFileFilterUsed(false);
        browse.addActionListener(new ButtonListener());
        inputPanel.add(browse, BorderLayout.PAGE_START);

        scaleLabel = new JLabel("Scale: ");
        scaleField = new JTextField(2);
        scaleLabel.setLabelFor(scaleField);
        inputPanel.add(scaleLabel, BorderLayout.PAGE_START);
        inputPanel.add(scaleField, BorderLayout.PAGE_START);

        transform = new JButton("Transform");
        transform.addActionListener(new ButtonListener());
        inputPanel.add(transform);

        panel.add(inputPanel, BorderLayout.PAGE_START);

        // textArea = new JTextArea(25, 50);
        // panel.add(textArea, BorderLayout.CENTER);
        textPanel = new TextPanel();
        // textPanel.setSize(panel.getWidth(), );
        textPanel.setOpaque(true);
        panel.add(textPanel, BorderLayout.CENTER);

        frame.getContentPane().add(panel);
        frame.pack();
        // frame.setResizable(false);
        frame.setVisible(true);
    }

    String path;
    double scale = 1;
    File file;
    BufferedImage img;
    int width, height;

    BufferedImage grayImg;
    int newWidth, newHeight;

    int size;
    int maxHeight;
    int fontSize;
    Font font;
    int rightshift = 0;

    HashMap <Integer, Character> map = new HashMap<>();

    String text = "";

    public void getFile() throws Exception {
        System.out.println("Retreieving File...");
        file = new File(path);
        img = ImageIO.read(file);
        width = img.getWidth();
        height = img.getHeight();
    }

    public BufferedImage resize() { 
        System.out.println("Resizeing Image...");
        Image tmp = img.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        BufferedImage dimg = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_RGB);
    
        Graphics2D g2d = dimg.createGraphics();
        g2d.drawImage(tmp, 0, 0, null);
        g2d.dispose();
    
        return dimg;
    }

    public void convert() throws Exception {
        System.out.println("Converting to GrayScale & Text...");

        for (int y = 0; y < newHeight; y++) {
            for (int x = 0; x < newWidth; x++) {
                int pixel = grayImg.getRGB(x,y);
                Color color = new Color(pixel, false);
                int red = color.getRed();
                int green = color.getGreen();
                int blue = color.getBlue();

                int gray = (int) Math.round(0.3 * red + 0.59 * green + 0.11 * blue);
                gray = gray > 255 ? 255 : gray;
                // System.out.print(gray + " ");
                int rgb = gray << 16 | gray << 8 | gray;

                grayImg.setRGB(x, y, rgb);

                text += map.get(gray);
                if (y == 0 && x == 0)
                    rightshift = size / 2 - textPanel.getFontMetrics(font).charWidth(map.get(gray)) / 2;
                // System.out.print(map.get(gray));
                // System.out.println(x + " " + y);
            }
            text += "\n";
            // System.out.println(text);
        }

        File fileOut = createFile(path.substring(0,path.indexOf(".")) + "GrayScale" + path.substring(path.indexOf(".")));
        ImageIO.write(grayImg, "JPG", fileOut);
    }

    public void getTextSize() {
        System.out.println("Calculating Maximum Text Size...");
        // FontMetrics fm = textArea.getFontMetrics(font);
        // FontMetrics fm = textPane.getFontMetrics(font);
        FontMetrics fm = textPanel.getFontMetrics(font);
        size = Math.max(fm.getHeight() , fm.getMaxAscent());
        maxHeight = fm.getMaxAscent();

        for (int i = 32; i <= 126; i ++) {
            Character c = (char) i;
            size = Math.max(size, fm.charWidth(c));
        }
        // size /= 2;

        System.out.println("Font Size in pixels: " + size);
    }

    public void getTextShade() {
        // System.out.println("Calculating Shades of Text...");

        // double[] weights = new double[256];
        // int max = 0;
        // int min = Integer.MAX_VALUE;

        // for (int c = 32; c <= 126; c ++) {
        //     int tsize = 10;
        //     BufferedImage bi = new BufferedImage(size * tsize / fontSize, size * tsize / fontSize, BufferedImage.TYPE_INT_ARGB); 
            
        //     Graphics2D g2d = bi.createGraphics();
        //     g2d.setFont(new Font("Times New Roman", Font.PLAIN, tsize));
        //     g2d.setColor(Color.BLACK);
        //     g2d.drawString(Character.toString((char) c), 0, maxHeight * tsize / fontSize);
        //     g2d.dispose();
        //     int count = 0;
        //     for (int j = 0; j < size * tsize / fontSize; j ++)
        //         for (int i = 0; i < size * tsize / fontSize; i ++) 
        //             count += bi.getRGB(i, j) == 0 ? 1 : 0;
        //     weights[c] = count;
        //     max = Math.max(max, count);
        //     min = Math.min(min, count);
        //     System.out.println((char) c + ": " + count);
        // }
        // double scaling = 255 / max;
        // for (int i = 32; i <= 126; i ++) 
        //     weights[i] = -weights[i] * scaling + 255;

        char[] list = new char[] {'$', '@', 'B', '%', '8', '&', 'W', 'M', '#', '*', 'o', 
                                'a', 'h', 'k', 'b', 'd', 'p', 'q', 'w', 'm', 'Z', 'O', '0', 
                                'Q', 'L', 'C', 'J', 'U', 'Y', 'X', 'z', 'c', 'v', 'u', 'n', 
                                'x', 'r', 'j', 'f', 't', '/', '\\', '|', '(', ')', '1', '{', 
                                '}', '[', ']', '?', '-', '_', '+', '~', '<', '>', 'i', '!', 
                                'l', 'I', ';', ':', ',', '"', '^', '`', '\'', '.', ' '};
        // System.out.println(list.length);
        // System.out.println((list.length - 1) / 255);
        System.out.println("Mapping...");
        for (int i = 0; i <= 255; i ++) {
            // double diff = Double.MAX_VALUE;
            // char c = ' ';
            // for (int j = 32; j <= 126; j ++) {
            //     if (Math.abs(i - weights[j]) <= diff) {
            //         diff = Math.abs(i - weights[j]);
            //         c = (char) j;
            //     }
            // }
            // System.out.println((double)((list.length - 1) / 255));
            // System.out.println((int) (-i * (double)((list.length - 1) / 255)));
            int c = (int) (i * (double)((list.length - 1)) / 255);
            c = c < 0 ? 0 : c;
            c = c > (list.length - 1) ? (list.length - 1) : c;
            // System.out.println(c);
            // System.out.println(i + ": " + list[c]);
            map.put(i, list[c]);
        }
    }

    public void toText() {
        System.out.println("Converting to Text...");
        for (int y = 0; y < newHeight; y++) {
            for (int x = 0; x < newWidth; x++) {
                int pixel = grayImg.getRGB(x,y);
                Color color = new Color(pixel, false);
                int shade = color.getRed();
                text += map.get(shade);
                System.out.print(map.get(shade));
            }
            // text += "\n";
            System.out.println();
        }
    }

    public File createFile(String p) {
        System.out.println("Creating File...");
        try {
            File myObj = new File(p);
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
                return myObj;
            } else {
                for (int i = 1; i <= 200; i ++) {
                    myObj = new File(p.substring(0,p.indexOf(".")) + " ("+ i +")" + path.substring(path.indexOf(".")));
                    if (myObj.createNewFile()) {
                        System.out.println("File created: " + myObj.getName());
                        return myObj;
                    }
                }
                System.out.println("File already exists.");
                System.out.println("An error occurred.");
                System.exit(1);
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return null;
    }

    public void reset() {
        textPanel = new TextPanel();
        widthShown = 0;
        heightShown = 0;

        path = "";
        scale = 1;
        file = null;
        img = null;
        width = 0; height = 0;

        grayImg = null;
        newWidth = 0; newHeight = 0;

        size = 0;
        maxHeight = 0;
        fontSize = 0;
        font = null;
        rightshift = 0;

        map = new HashMap<>();

        text = "";
    }

    public class ButtonListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            if (e.getActionCommand().equals("Browse")) {
                if (fileChooser.showOpenDialog(panel) == JFileChooser.APPROVE_OPTION) {
                    path = fileChooser.getSelectedFile().getAbsolutePath();
                    pathField.setText(path);
                }
            }
            if (e.getActionCommand().equals("Transform")) {
                try {
                    // reset();

                    path = pathField.getText();
                    if (!scaleField.getText().equals("")) {
                        scale = Double.parseDouble(scaleField.getText());
                        scale = (double) Math.round(scale * 10) / 10;
                        scale = scale > 0 ? scale: 0.1;
                        scale = scale > 1 ? 1 : scale;
                        scaleField.setText(Double.toString(scale));
                    }
                    System.out.println(scale);
                    ITT.getFile();

                    newWidth = (int) (width * scale);
                    newHeight = (int) (height * scale);
                    System.out.println(newWidth + " " + newHeight);
                    grayImg = resize();

                    widthShown = panel.getWidth();
                    double ratio = (double) (widthShown / newWidth);

                    heightShown = (int) (newHeight * ratio);

                    // textArea = new JTextArea(newHeight, newWidth);
                    // textPanel = new TextPanel();
                    textPanel.setSize(widthShown, heightShown);
                    textPanel.setOpaque(true);
                    
                    fontSize = (int) (ratio * 3 / 4);
                    fontSize = fontSize > 0 ? fontSize : 1;
                    // System.out.println(widthShown + " " + newWidth + " " + ratio + " " + fontSize);
                    Map<TextAttribute, Object> attribute = new HashMap<TextAttribute, Object>();
                    // attribute.put(TextAttribute.WEIGHT, 500000000);
                    // attribute.put(TextAttribute.TRACKING, -0.2);
                    attribute.put(TextAttribute.WIDTH, size);
                    font = new Font(Font.MONOSPACED, Font.BOLD, fontSize).deriveFont(attribute);
                    // font = new Font(Font.MONOSPACED, Font.BOLD, fontSize);
                    // textArea.setFont(font);
                    // textArea.setAlignmentX(Component.CENTER_ALIGNMENT);
                    // textArea.set

                    // textPane = new JTextPane(null);
                    // textPane.setFont(font);
                    // textPane.setSize(widthShown, heightShown);

                    textPanel.setFont(font);

                    ITT.getTextSize();
                    ITT.getTextShade();

                    ITT.convert();
                    // ITT.toText();

                    // textArea.setText(text);
                    // textArea.set
                    // panel.add(textArea, BorderLayout.CENTER);
                    // panel.add(textPane, BorderLayout.CENTER);
                    textPanel.setFontSize(size);
                    textPanel.setBaseLine(maxHeight);
                    textPanel.setText(text);
                    textPanel.rightshift = rightshift;
                    textPanel.repaint();
                    // panel.add(textPanel, BorderLayout.CENTER);
                    
                    frame.setSize(frame.getWidth(), textPanel.getHeight() + panel.getHeight());
                    // frame.setContentPane(panel);
                    // frame.pack();
                    // frame.setVisible(true);

                } catch (Exception ee) {}
            }
        }
        
    }

    public static void main(String[] args) throws Exception {
        ITT = new ImageToText();
        // ITT.reset();
    }

}