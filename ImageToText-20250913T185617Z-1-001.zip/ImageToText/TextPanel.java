import java.awt.Font;
import java.awt.Graphics;
import java.awt.font.TextAttribute;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JPanel;

public class TextPanel extends JPanel {

    char[][] text = new char[][]{};
    int size = 0;
    int baseline = 0;
    int rightshift = 0;
    Font font;

    @Override
    protected void paintComponent(Graphics g) {
        g.setFont(font);
        super.paintComponent(g);
        g.clearRect(0, 0, 1000, 1000);
        for (int i = 0; i < text.length; i ++) {
            for (int j = 0; j < text[i].length; j ++) {
                g.drawString(Character.toString(text[i][j]), (int) (j * size + rightshift / (1.5)), (int) (i * size + baseline * (1.5)));
            }
        }

    }

    @Override
    public void setFont(Font font) {
        super.setFont(font);

        Map<TextAttribute, Object> attribute = new HashMap<TextAttribute, Object>();
                    // attribute.put(TextAttribute.WEIGHT, 500000000);
                    // attribute.put(TextAttribute.TRACKING, -0.2);
                    attribute.put(TextAttribute.WIDTH, size);
                    attribute.put(TextAttribute.SIZE, font.getSize() * 1.5);
                    this.font = font.deriveFont(attribute);

        // this.font = font;

    }
    
    public void setText(String t) {
        String[] a = t.split("\n");
        this.text = new char[a.length][a[0].length()];
        for (int i = 0; i < a.length; i ++)
            this.text[i] = a[i].toCharArray();
    }

    public void setFontSize(int size) {
        this.size = size;
    }

    public void setBaseLine(int baseline) {
        this.baseline = baseline;
    }

}
