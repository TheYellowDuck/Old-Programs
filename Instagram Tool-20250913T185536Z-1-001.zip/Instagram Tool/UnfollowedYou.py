from itertools import count
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

username = 'georgezhang006'
password = 'Gz95061303$'
count = 0

def login(driver):
    driver.find_element(By.NAME, "username").send_keys(username)
    driver.find_element(By.NAME, "password").send_keys(password)
    driver.find_element(By.NAME, "password").send_keys(u'\ue007')

def click_button_with_css(driver, css_selector):
    element = WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, css_selector)))
    element.click()

def navigate_to_followers(driver):
    dropdown_css = '[alt*="' + username + '"]'
    profile_css = "[href*=\"" + username + "\"]"
    click_button_with_css(driver, dropdown_css)
    click_button_with_css(driver, profile_css)

def __main__():
    driver = webdriver.Chrome(ChromeDriverManager().install())
    driver.get('https://www.instagram.com/accounts/login')
    time.sleep(1)
    login(driver)
    navigate_to_followers(driver)

    followers_css = "[href*=\"" + username + "/followers/\"]"
    css_select_close = '[aria-label="Close"]'
    following_css = "[href*=\"" + username + "/following/\"]"

    click_button_with_css(driver, followers_css)
    followers_list = get_usernames_from_dialog(driver, 1)
    click_button_with_css(driver, css_select_close)
    time.sleep(2)
    click_button_with_css(driver, following_css)
    following_list = get_usernames_from_dialog(driver, 2)
    
    print (followers_list, following_list)
    
    unfollowed = Unfollowed(followers_list, following_list)

    for i in range(len(unfollowed)):
        print(unfollowed[i])

    time.sleep(10000)
    return

def Unfollowed(followers, following):
    followers.sort()
    following.sort()
    unfollowed = []
    
    for i in range(len(following)):
        try:
            followers.index(following[i])
        except ValueError:
            unfollowed += [following[i]]

    return unfollowed

def check_difference_in_count(driver, i, element):
    driver.execute_script("arguments[0].scrollIntoView(true);",element[i])
    global count
    # print (count)
    new_count = len(driver.find_elements(By.XPATH, "//div[@class='_ab8w  _ab94 _ab97 _ab9f _ab9k _ab9p  _ab9- _aba8 _abcm']"))
    # print(new_count)
    if count != new_count:
        count = new_count
        return True
    else:
        count = 0
        print("why")
        return False
    
def get_usernames_from_dialog(driver, num):
    list_xpath = "//div[@class='_ab8w  _ab94 _ab97 _ab9f _ab9k _ab9p  _ab9- _aba8 _abcm']"
    # WebDriverWait(driver, 20).until(
    #     EC.presence_of_element_located((By.XPATH, list_xpath)))
    pop_up_window = WebDriverWait(
    driver, 2).until(EC.element_to_be_clickable(
        (By.XPATH, "//div[@class='_aano']")))
    scroll_down(driver, num)

    list_elems = driver.find_elements(By.XPATH, list_xpath)
    time.sleep(1)

    users = []
    for i in range(len(list_elems)):
        try:
            row_text = list_elems[i].text
            if "Remove" in row_text or "Following" in row_text:
                username = row_text[:row_text.index("\n")]
                users += [username]
        except:
            print("continue")
    return users

def scroll_down(driver, num):
    follower_number  =int(driver.find_elements(By.XPATH, '//span [@class="_ac2a"]')[num].text)
    print(follower_number)
    i = 0 

    # looping for the exact number of followers ...
    while(i<follower_number):
        # as the website is dyanamic so updating the follwers list and also the webelement 
        element = driver.find_elements(By.XPATH, "//div[@class='_ab8w  _ab94 _ab97 _ab9f _ab9k _ab9p  _ab9- _aba8 _abcm']")
        # executing scroll into view script to view the element and thats gonna load the next element(follower ) ..ultimately your scrolling achived
        # check_difference_in_count(driver, i, element)
        driver.execute_script("arguments[0].scrollIntoView(true);",element[-1])
        time.sleep(1.5)
        # print(i)
        i=len(element)
    # global count
    # # iter = 0
    # while True:
    #     print("scrolling")
    #     # scroll_top_num = str(iter * 1000)
    #     # iter += 1
    #     driver.execute_script(
    #         'arguments[0].scrollTop = arguments[0].scrollTop + arguments[0].offsetHeight;', 
    #     pop_up_window)

    #     time.sleep(1)

    #     if (not check_difference_in_count(driver)):
    #         break;

        # try:
        #     WebDriverWait(driver, 1).until(check_difference_in_count(driver))
        # except:
        #     print("out")
        #     count = 0
        #     break;
    # global count
    # iter = 0
    # while 1:
    #     print(iter)
        # scroll_top_num = str(iter * 1000)
        # iter += 1
        # driver.execute_script("document.querySelector('div[class=_aano]').parentNode.scrollTop=" + scroll_top_num)

        # try:
        #     WebDriverWait(driver, 1).until(check_difference_in_count(driver))
        # except:
        #     count = 0
        #     break;
    # while True:
    #     placecount += 1
    #     driver.execute_script(
    #         'arguments[0].scrollTop = arguments[0].scrollTop + arguments[0].offsetHeight;', 
    #     pop_up_window)
    return

__main__()