#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int T;

int R, C;
int count[20][20];
char maze[21][21];

int Q[400][2];
int addi = 0;
int geti = -1;
int size = 0;
static inline void add(int x, int y) {
    if (addi == 400) addi = 0;
    Q[addi][0] = x;
    Q[addi ++][1] = y;
    size ++;
}
static inline void get(int *x, int* y) {
    ++ geti;
    if (geti == 400) geti = 0;
    *x = Q[geti][0];
    *y = Q[geti][1];
    size --;
}

int main() {
    scanf("%d", &T);
    
    for (int i = 0; i < T; i ++) {
        scanf("%d\n%d", &R, &C);
        memset(count, 0, sizeof(count));
        for (int j = 0; j < R; j ++) 
            scanf("%s", &maze[j]);
        count[0][0] = 1;
        add(0, 0);
        while (size) {
            int x, y;
            get(&x, &y);
            // printf("%d %d\n", x, y);
            if (x == R - 1 && y == C - 1) goto end;
            if (maze[x][y] == '+') {
                if (x - 1 >= 0 && count[x - 1][y] == 0 && maze[x - 1][y] != '*') {
                    count[x - 1][y] = count[x][y] + 1;
                    add(x - 1, y);
                }
                if (x + 1 < R && count[x + 1][y] == 0 && maze[x + 1][y] != '*') {
                    count[x + 1][y] = count[x][y] + 1;
                    add(x + 1, y);
                }
                if (y - 1 >= 0 && count[x][y - 1] == 0 && maze[x][y - 1] != '*') {
                    count[x][y - 1] = count[x][y] + 1;
                    add(x, y - 1);
                }
                if (y + 1 < C && count[x][y + 1] == 0 && maze[x][y + 1] != '*') {
                    count[x][y + 1] = count[x][y] + 1;
                    add(x, y + 1);
                }
            }
            else if (maze[x][y] == '|') {
                if (x - 1 >= 0 && count[x - 1][y] == 0 && maze[x - 1][y] != '*') {
                    count[x - 1][y] = count[x][y] + 1;
                    add(x - 1, y);
                }
                if (x + 1 < R && count[x + 1][y] == 0 && maze[x + 1][y] != '*') {
                    count[x + 1][y] = count[x][y] + 1;
                    add(x + 1, y);
                }
            }
            else {
                if (y - 1 >= 0 && count[x][y - 1] == 0 && maze[x][y - 1] != '*') {
                    count[x][y - 1] = count[x][y] + 1;
                    add(x, y - 1);
                }
                if (y + 1 < C && count[x][y + 1] == 0 && maze[x][y + 1] != '*') {
                    count[x][y + 1] = count[x][y] + 1;
                    add(x, y + 1);
                }
            }
            // for (int n = 0; n < R; n ++) {
            //     for (int m = 0; m < C; m ++) {
            //         printf("%d ", count[n][m]);
            //     }
            //     printf("\n");
            // }
            // printf("\n");
        }
        end:;
        if (count[R - 1][C - 1]) printf("%d\n", count[R - 1][C - 1]);
        else printf("-1\n");
    }
    
    return 0;
}