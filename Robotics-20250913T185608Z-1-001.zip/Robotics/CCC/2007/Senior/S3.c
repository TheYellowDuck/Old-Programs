#include <stdio.h>
#include <stdlib.h>

int friends[10000];
int N;

int main() {
    scanf("%d", &N);
    for (int i = 0; i < N; i ++) {
        int a, b;
        scanf("%d %d", &a, &b);
        friends[a] = b;
    }
    int x, y;
    scanf("%d %d", &x, &y);
    while (x) {
        int dist = 0;
        int cur = friends[x];
        while (cur != y && cur != x) {
            cur = friends[cur];
            dist ++;
        }
        if (cur == y) printf("Yes %d\n", dist);
        else printf("No\n");
        scanf("%d %d", &x, &y);
    }
    
    return 0;
}