#include <stdio.h>
#include <stdlib.h>

int connections[100000000];
int count[10000];
// int to[10000];
// int come[10000];
// int l = -1, r = 0, size = 0;
// int parent, child;

static inline int encode(int x, int y) {
    return x * 10000 + y;
}

// static inline void add (int in, int out) {
//     come[r] = in;
//     to[r ++] = out;
//     size ++;
// }

// static inline void pop () {
//     if (size != 0) {
//         parent = come[++ l];
//         child = to[l];
//         size --;
//     }
//     else {
//         parent = -1;
//         child = -1;
//     }
// }

int main() {
    int N;
    scanf("%d", &N);
    int a, b;
    do {
        scanf("%d %d", &a, &b);
        // printf("%d %d\n", a, b);
        connections[encode(b, a)] = 1;
        connections[b * 10000] ++;
        // printf("%d %d\n", a, b);
    }
    while (a != 0);
    // add(0, N);
    // while (size != 0) {
    //     pop();
    //     printf("%d %d %d\n", parent, child, count[1]);
    //     count[child] ++;
    //     int c = connections[child * 10000];
    //     for (int i = 1; i < N; i ++) {
    //         if (connections[encode(child, i)] == 1) {
    //             add(child, i);
    //             c--;
    //         }
    //         if (c == 0) break;
    //     }
    // }
    count[N] = 1;
    for (int i = N; i >= 1; i --) {
        int c = connections[i * 10000];
        for (int j = 1; j <= N; j ++) {
            if (connections[encode(i, j)] == 1) {
                count[j] += count[i];
                c--;
            }
            if (c == 0) break;
        }
    }
    printf("%d\n", count[1]);
    return 0;
}