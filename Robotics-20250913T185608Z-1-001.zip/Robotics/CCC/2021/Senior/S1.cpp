#include <iostream>
#include <bits/stdc++.h>
#include <cstdio>
using namespace std;

int H[10001];
int N;

int main() {
    scanf("%d", &N);
    for (int i = 0; i <= N; i ++) 
        scanf("%d", &H[i]);
    double A = 0;
    for (int i = 1; i <= N; i ++) {
        int W;
        scanf("%d", &W);
        A += (min(H[i], H[i - 1]) + abs(H[i] - H[i - 1]) / 2.0) * W;
    }
    printf("%f\n", A);
}