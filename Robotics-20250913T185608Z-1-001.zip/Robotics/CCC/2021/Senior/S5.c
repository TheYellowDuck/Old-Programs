#include <stdio.h>
#include <stdlib.h>

int A[150001][17];
int primes[6] = {2, 3, 5, 7, 11, 13};

int main() {
    int N, M;
    scanf("%d %d", &N, &M);
    for (int i = 0; i < M; i ++) {
        int x, y, z;
        scanf("%d %d %d", x, y, z);
        A[x][z] = z;
        A[y][z] = -z;
    }
    for (int i = 1; i <= N; i ++) {
        int V = 1;
        for (int j = 1; j < 17; j ++) {
            A[i][j] += A[i - 1][j]; 
            if (A[i][j] > j) A[i][j] = j;
            int value = A[i][j], similiar = 1;
            for (int k = 0; k < 6; k ++) {
                while (value % primes[k] == 0 && V % primes[k] == 0) {
                    similiar *= primes[k];
                    value /= primes[k];
                    V /= primes[k];
                }
            }
            V = V * value * similiar;
        }
        A[i][0] = V;
    }
    for (int i = 0; i < M; i ++) {
        
    }
    return 0;
}