#include <stdio.h>
#include <stdlib.h>

int min(long a, long b) {
    if (a <= b) return a;
    return b;
}

typedef struct {
    int P;
    int W;
    int D;
} friend;

friend friends[200000];
int N;
long minT = LONG_MAX;
// long Left = 0, Right = 0;

int compare(const void *a, const void *b) {
  
    friend *A = (friend *)a;
    friend *B = (friend *)b;
  
    if(A -> P < B -> P)
        return -1;
    if(A -> P > B -> P)
        return 1;
    
    return 0;
}

int sumtime(int x) {
    long left = 0, right = 0;
    for (int i = 0; i < N; i ++) {
        if (x > friends[i].P + friends[i].D)
            left += friends[i].W * (x - friends[i].P - friends[i].D);
        else if (x < friends[i].P - friends[i].D)
            right += friends[i].W * (friends[i].P - friends[i].D - x);
    }
    // if (minT <= left + right) return 0;
    minT = min(minT, left + right);
    if(left < right)
        return 1;
    if(left > right)
        return -1;
    return 0;
}

void binarysearch(int l, int r) {
    if (l > r) return;
    int m = l + (r - l) / 2;
    int v = sumtime(m);
    // printf("%d %d %ld\n", m, v, minT);
    if (v == 0) {
        long temp = minT;
        for (int i = m + 1; i <= 200000; i ++) {
            int v2 = sumtime(i);
            if (temp == minT)
                break;
            temp = minT;
        }
        temp = minT;
        for (int i = m - 1; i >= 0; i --) {
            int v2 = sumtime(i);
            if (temp == minT)
                break;
            temp = minT;
        }
        return;
    }
    if (v == -1)
        binarysearch(l, m - 1);
    else
        binarysearch(m + 1, r);
}

int main() {
    scanf("%d", &N);
    for (int i = 0; i < N; i ++) 
        scanf("%d %d %d", &friends[i].P, &friends[i].W, &friends[i].D);
    qsort(friends, N, sizeof(friend), compare);
    // for (int i = 0; i < N; i ++) 
    //     printf("%d %d %d\n", friends[i].P, friends[i].W, friends[i].D);
    binarysearch(friends[0].P, friends[N - 1].P);
    printf("%ld\n", minT);
}