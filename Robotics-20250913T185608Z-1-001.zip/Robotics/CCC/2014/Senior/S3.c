#include <stdio.h>
#include <stdlib.h>

int T;
int N;
int cars[10000];
int branch[10000];
int pos = -1;

int main() { 
    scanf("%d", &T);
    while (T > 0) {
        scanf("%d", &N);
        for (int i = N - 1; i >= 0; i --) 
            scanf("%d", &cars[i]);

        pos = -1;
        int curcar = 1;

        for (int i = 0; i < N; i ++) {
            int car = cars[i];
            if (car == curcar) {
                curcar ++;
                while (pos >= 0) {
                    if (branch[pos] != curcar) break;
                    pos --;
                    curcar ++;
                }
            }
            else 
                branch[++ pos] = car;
        }
        if (curcar == N + 1) printf("Y\n");
        else printf("N\n");
        T--;
    }
    return 0;
}