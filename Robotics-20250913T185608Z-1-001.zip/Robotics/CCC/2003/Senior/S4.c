#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int N;

int main() { 
    scanf("%d", &N);
    while (N > 0) {
        char str[5001];
        scanf("%s");

        N --;
    }
    return 0;
}