#include <stdio.h>
#include <math.h>
#include <string.h>
#include <limits.h>
using namespace std;

int N;
int A[5000][5000];
int O[5000];

int main() {
    scanf("%d", &N);
    int m = INT_MAX;
    for (int i = 0; i < N; i ++) {
        scanf("%d", &O[i]);
        if (i - 1 >= 0) {
            A[1][i - 1] = abs(O[i - 1] - O[i]);
            m = m < A[1][i - 1] ? m : A[1][i - 1];
            // printf ("%d ", A[1][i - 1]);
        }
    }
    printf("0 ");
    // printf("\n");
    if (1 < N) {
        printf("%d ", m);
        // printf("\n");
    }
    for (int i = 2; i < N; i ++) { // (i - 1) / 2
        m = INT_MAX;
        for (int j = i / 2; j - i / 2 < N - i; j ++) {
            if (i % 2 == 0) 
                A[i][j] = A[i - 2][j] + abs (O[j - i / 2] - O[j + i / 2]);
            else 
                A[i][j] = A[i - 2][j] + abs(O[j - i / 2] - O[j + i / 2 + 1]);
            m = m < A[i][j] ? m : A[i][j];
            // printf("%d ", A[i][j]);
        }
        printf("%d ", m);
        // printf("\n");
    }
    printf("\n");
}