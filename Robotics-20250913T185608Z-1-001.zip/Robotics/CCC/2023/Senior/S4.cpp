#include <stdio.h>
#include <vector>
#include <queue>
#include <string.h>
#include <algorithm>
#include <set>
// #include <limits.h>
using namespace std;

int N, M;
long cost = 0;

struct Path {
    int a, b;
    int l, c;
};

vector<int> paths[2001];
vector<int> npaths[2001];
Path P[2000];
int R[2001];
int C[2001];
long maxP[2001][2001];

int compare (Path a, Path b) {
    if (a.c == b.c) {
        return a.l < b.l;
    }
    else return a.c < b.c
}

void merge (int a, int b) {

}

int main() {
    scanf("%d %d", &N, &M);
    for (int i = 0; i < M; i ++) {
        scanf("%d %d %d %d", &P[i].a, &P[i].b, &P[i].l, &P[i].c);
        paths[P[i].a].push_back(i);
        paths[P[i].b].push_back(i);
    }

    memset(&maxP, -1, sizeof(maxP));
    // for (int i = 0; i < 2001; i ++) {
    //     for (int j = 0; j < 2001; j ++)
    //         printf("%ld ", maxP[i][j]);
    //     printf("\n");
    // }

    queue<pair<int, int>> Q;
    for (int i = 1; i <= N; i ++) {
        Q.emplace(make_pair(i, i));
        maxP[i][i] = 1;
        R[i] = i;
        C[i] = 1;
    }
    while (!Q.empty()) {
        pair<int, int> cur = Q.front();
        Q.pop();
        for (int i : paths[cur.second]) {
            int next = P[i].a == cur.second ? P[i].b : P[i].a, l = P[i].l, c = P[i].c;
            if (maxP[cur.first][next] == -1) {
                maxP[cur.first][next] = maxP[cur.first][cur.second] + l;
                Q.emplace(make_pair(cur.first, next));
            }
            else if (maxP[cur.first][next] < maxP[cur.first][cur.second] + l ) {
                maxP[cur.first][next] = maxP[cur.first][cur.second] + l;
                Q.emplace(make_pair(cur.first, next));
            }
            maxP[next][cur.first] = maxP[cur.first][next];
        }
    }
    sort(P, &P[M], compare);
    // set<int> included;
    for (int i = 0; i < M; i ++) {
        // vector<
        // for (int j = 1; j <= N; j ++) {
        //     if ((maxP[j][P[i].a] < maxP[j][P[i].b] + P[i].l) || (maxP[j][P[i].b] < maxP[j][P[i].a] + P[i].l)) goto next;
        // }
        npaths[P[i].a].emplace(i);
        npaths[P[i].b].emplace(i);
        if (C[R[P[i].a]] > C[R[P[i].b]]) {
            C[R[P[i].a]] ++;
            queue<int> Q2;
            Q2.emplace(P[i].b);
            while (!Q.empty()) {
                Q
            }
        }
        // included.emplace(P[i].a);
        // included.emplace(P[i].b);
        cost += i.c;
        next:;
    }

}