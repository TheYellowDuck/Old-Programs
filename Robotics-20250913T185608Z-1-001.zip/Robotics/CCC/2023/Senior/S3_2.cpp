#include <stdio.h>
#include <math.h>
#include <string.h>
using namespace std;

int N, M, R, C;
char P[2000][2000];

int main() {
    scanf("%d %d %d %d", &N, &M, &R, &C);
    if (N % 2 == 0) {
        for (int i = 0; i < R / 2; i ++) {
            for (int j = 0; j < M; j ++) {
                if (i == 0) {
                    P[i][j] = 'a';
                    P[N - i - 1][j] = 'a'
                }
                else {
                    P[i][j] = (P[i - 1][j] - 'a' + 1) % 26 + 'a';
                    P[N - i - 1][j] = (P[N - i][j] - 'a' + 1) % 26 + 'a';
                }
            }
        }
        if (R % 2 == 1) {
            for (int j = 0; j < M; j ++) {
                if (R == 1) {
                    P[i][j] = 'a';
                    P[N - i - 1][j] = 'a'
                }
                else {
                    P[i][j] = (P[i - 1][j] - 'a' + 1) % 26 + 'a';
                    P[N - i - 1][j] = (P[N - i][j] - 'a' + 1) % 26 + 'a';
                }
            }
        }
    }

    if (RC != R || CC != C) printf("IMPOSSIBLE\n");
    else {
        for (int i = 0; i < N; i ++) {
            for (int j = 0; j < M; j ++) {
                printf("%c", P[i][j]);
            }
            printf("\n");
        }
    }
}