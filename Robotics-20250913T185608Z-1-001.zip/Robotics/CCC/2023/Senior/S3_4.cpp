#include <stdio.h>
#include <math.h>
#include <string.h>
using namespace std;

int N, M, R, C;
char P[2000][2000];

int main() {
    memset(&P, 'a', sizeof(P));
    scanf("%d %d %d %d", &N, &M, &R, &C);
    for (int i = R; i < N; i ++) 
        for (int j = C; j < M; j ++) 
            P[i][j] = rand() % 25 + 'b';
    if (R == 0 && C == M) {
        for (int i = 1; i < M; i ++) 
            for (int j = 0; j < N; j ++) 
                P[j][i] = (P[j][i - 1] - 'a' + 1) % 26 + 'a';
    }
    else if (C == 0 && R == N) {
        for (int i = 1; i < N; i ++) 
            memset(&P[i], (P[i - 1][0] - 'a' + 1) % 26 + 'a', M * sizeof(char));
    }
    int RC = N, CC = M;
    for (int i = 0; i < N; i ++) {
        int a, b;
        if (M % 2 == 0) {
            a = M / 2 - 1;
            b = M / 2;
        }
        else {
            a = M / 2 - 1;
            b = M / 2 + 1;
        }
        for (; a >= 0; a --, b ++) {
            if (P[i][a] != P[i][b]) {
                RC --;
                break;
            }
        }
    }
    for (int i = 0; i < M; i ++) {
        int a, b;
        if (N % 2 == 0) {
            a = N / 2 - 1;
            b = N / 2;
        }
        else {
            a = N / 2 - 1;
            b = N / 2 + 1;
        }
        for (; a >= 0; a --, b ++) {
            if (P[a][i] != P[b][i]) {
                CC --;
                break;
            }
        }
    }

    if (RC != R || CC != C) printf("IMPOSSIBLE\n");
    else {
        for (int i = 0; i < N; i ++) {
            for (int j = 0; j < M; j ++) {
                printf("%c", P[i][j]);
            }
            printf("\n");
        }
    }
}