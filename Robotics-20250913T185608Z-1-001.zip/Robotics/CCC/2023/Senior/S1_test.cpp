#include <stdio.h>
using namespace std;

int N;
int A[2][200001];
int P = 0;

int main() {
    scanf("%d", &N);
    for (int i = 1; i <= N; i ++) {
        scanf("%d", &A[0][i]);
        if (A[0][i] == 1) {
            if (A[0][i - 1] == 0)
                P += 3;
            else 
                P += 1;
        }
    }
    for (int i = 1; i <= N; i ++) {
        scanf("%d", &A[1][i]);
        if (A[1][i] == 1) {
            if (A[1][i - 1] == 0)
                P += 3;
            else 
                P += 1;
            if (i % 2 == 1 && A[0][i] == 1) P -= 2;
        }
    }
    printf("%d\n", P);
}