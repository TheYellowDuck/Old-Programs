#include <stdio.h>
#include <math.h>
#include <string.h>
using namespace std;

int N, M, R, C;
char P[2000][2000];
int H[2000];
int V[2000];

int main() {
    scanf("%d %d %d %d", &N, &M, &R, &C);
    for (int i = 0; i < R / 2; i ++) {
        H[i] = 1;
        H[N - i - 1] = 1;
    }
    if (R % 2 == 1) {
        H[N / 2 - 1] = 1;
        if (N % 2 == 0) H[N / 2] = -1;
    }
    for (int i = 0; i < C / 2; i ++) {
        V[i] = 1;
        V[N - i - 1] = 1;
    }
    if (C % 2 == 1)  {
        V[M / 2] = 1;
        if (M % 2 == 0) V[M / 2] = -1;
    }
    
    for (int i = 0; i < N; i ++) {
        if (H[i] == 1) {
        }
    }
    

    if (RC != R || CC != C) printf("IMPOSSIBLE\n");
    else {
        for (int i = 0; i < N; i ++) {
            for (int j = 0; j < M; j ++) {
                printf("%c", P[i][j]);
            }
            printf("\n");
        }
    }
}