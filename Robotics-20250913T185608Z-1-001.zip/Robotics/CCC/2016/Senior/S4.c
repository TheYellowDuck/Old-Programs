#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int riceballs[401];
int cnt[400];
int N;
// int access = 2;

int recurse (int A[401], int start, int l) {
    // for (int i = 0; i < l; i ++) {
    //     printf("%d ", A[i]);
    // }
    // printf("\n");
    start = start > 0 ? start : 0;
    int max = A[400];
    for (int i = start; i < l - 2; i ++) {
        if (A[i] == A[i + 1]) {
            int newA[401];
            if (i != 0)
                memcpy(newA, A, i * sizeof(int));
            newA[i] = (A[i] << 1);
            int newMax = max > newA[i] ? max : newA[i];
            newA[400] = newMax;
            if (l - i - 2 > 0)
                memcpy(&newA[i + 1], &A[i + 2], (l - i - 2) * sizeof(int));
            int m = recurse (newA, i - 2, l - 1);
            max = max > m ? max : m;
        }
        if (A[i] == A[i + 2]) {
            int newA[401];
            if (i != 0)
                memcpy(newA, A, i * sizeof(int));
            newA[i] = (A[i] << 1) + A[i + 1];
            int newMax = max > newA[i] ? max : newA[i];
            newA[400] = newMax;
            if (l - i - 3 > 0)
                memcpy(&newA[i + 1], &A[i + 3], (l - i - 3) * sizeof(int));
            int m = recurse (newA, i - 2, l - 2);
            max = max > m ? max : m;
        }
    }

    if (A[l - 2] == A[l - 1]) {
        int newA[401];
        if (l - 2 != 0)
            memcpy(newA, A, (l - 2) * sizeof(int));
        newA[l - 2] = (A[l - 2] << 1);
        int newMax = max > newA[l - 2] ? max : newA[l - 2];
        newA[400] = newMax;
        if (l - (l - 2) - 2 > 0)
            memcpy(&newA[l - 2 + 1], &A[l - 2 + 2], (l - (l - 2) - 2) * sizeof(int));
        int m = recurse (newA, l - 2 - 2, l - 1);
        max = max > m ? max : m;
    }
    // printf("%d\n", max);
    return max;
}

int main() {
    scanf("%d", &N);
    int max = 0;
    for (int i = 0; i < N; i ++) {
        int s;
        scanf("%d", &s);
        riceballs[i] = s;
        max = max > s ? max : s;
    }
    riceballs[400] = max;
    printf("%d\n", recurse(riceballs, 0, N));
    return 0;
}