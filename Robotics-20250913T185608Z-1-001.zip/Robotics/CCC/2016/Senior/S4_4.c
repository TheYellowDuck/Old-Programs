#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int RB[401][400];
int N;

int main() {
    scanf("%d", &N);
    for (int i = 0; i < N; i ++) 
        scanf("%d", &RB[1][i]);
    for (int i = 2; i <= N; i ++) {
        // for (int j = 0; j <= N - i; j ++) {
        //     for (int k = 1; k < i; k ++) {
        //         if (RB[k][j] == RB[i - k][j + k]) {
        //             RB[i][j] = RB[k][j] << 1;
        //             goto found;
        //         }
        //         for (int l = 1; l < i - k; l ++) {
                    
        //         }
        //     }
        //     found:;
        // }

        for (int j = 1; j < i; j ++) {
            for (int k = 0; k < N - j; k ++) {
                if (RB[j][k] == RB[i - j][k + j]) {
                    RB[i][k] = RB[j][k] + RB[i - j][k + j];
                }
            }
            for (int k = 1; k < i - j; k ++) {
                for (int l = 0; l < N - j; l ++) {
                    if (RB[j][l] == RB[k][l + j + (i - j - k)]) {  // i - (j + i - k) = k - j
                        RB[i][l] = RB[j][l] + RB[k][l + j + (i - j - k)] + RB[i - j - k][l + j];
                    }
                }
            }
        }
        for (int j = 0; j < N; j ++) {
            printf("%d ", RB[i][j]);
        }
        printf("\n");
    }
    int max = 0;
    for (int i = 0; i < N; i ++) {
        max = max > RB[N][i] ? max : RB[N][i];
    }
    printf("%d\n", max);
    return 0;
}