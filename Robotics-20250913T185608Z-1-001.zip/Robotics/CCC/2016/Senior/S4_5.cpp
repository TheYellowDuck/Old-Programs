#include <stdio.h>
using namespace std;

int A[400][400];
int N;
int max = 0;

inline int merge(int a, int b) {
    // printf("%d %d\n", a, b);
    // if (A[a][b] != 0) return A[a][b];
    int sum = 0;
    for (int i = a; i < b; i ++) {
        // printf("from: %d %d\n", a, b);
        int ar;
        if (A[a][i] != 0) ar = A[a][i];
        else ar = merge(a, i);
        if (ar == -1) continue;
        int br;
        if (A[i + 1][b] != 0) br = A[i + 1][b];
        else br = merge(i + 1, b);
        if (br == -1) continue;
        if (ar == br) {
            sum = ar + br;
            goto done;
        }
    }
    for (int i = a; i < b - 1; i ++) {
        int ar;
        if (A[a][i] != 0) ar = A[a][i];
        else ar = merge(a, i);
        if (ar == -1) continue;
        for (int j = i + 2; j <= b; j ++) {
            // printf("from: %d %d\n", a, b);
            int br;
            if (A[j][b] != 0) br = A[j][b];
            else br = merge(j, b);
            if (br == -1) continue;
            if (ar == br) {
                int cr;
                if (A[i + 1][j - 1] != 0) cr = A[i + 1][j - 1];
                else cr = merge(i + 1, j - 1);
                if (cr == -1) goto cont;
                sum = ar + br + cr;
                goto done;
            }
            cont:;
        }
    }
    done:;
    if (sum == 0) A[a][b] = -1; //if sum is 0 return -1
    else A[a][b] = sum; //else return sum;
    max = max > A[a][b] ? max: A[a][b];
    // printf("%d %d %d\n", a, b, A[a][b]);
    return A[a][b];
}

int main() {
    scanf("%d", &N);
    for (int i = 0; i < N; i ++) {
        scanf("%d", &A[i][i]);
        max = max > A[i][i] ? max: A[i][i];
    }
    merge (0, N - 1);
    // for (int i = 0; i < N; i ++) {
    //     for (int j = i; j < N; j ++) {
    //         merge (i, j);
    //     }
    // }
    printf("%d\n", max);
}