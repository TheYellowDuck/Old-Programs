#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int riceballs[401];
int cnt[400];
int N;
// int access = 2;

int recurse (int A[401], int start) {
    // for (int i = 0; i < l; i ++) {
    //     printf("%d ", A[i]);
    // }
    // printf("\n");
    start = start > 0 ? start : 0;
    int max = A[400];
    // for (int i = start; i < l - 2; i ++) {
    for (int i = start; i < N - 1; i ++) {
        if (A[i] == -1) continue;
        if (cnt[i] == 1) continue;
        int change = 1;
        if (A[i] == A[i + 1]) {
            change = 0;
            // int newA[401];
            // if (i != 0)
            //     memcpy(newA, A, i * sizeof(int));
            // newA[i] = (A[i] << 1);
            // int newMax = max > newA[i] ? max : newA[i];
            // newA[400] = newMax;
            // if (l - i - 2 > 0)
            //     memcpy(&newA[i + 1], &A[i + 2], (l - i - 2) * sizeof(int));
            // int m = recurse (newA, i - 2, l - 1);
            // max = max > m ? max : m;
            int newA[401];
            memcpy(newA, A, 401 * sizeof(int));
            newA[i] = (A[i] << 1);
            newA[i + 1] = -1;
            if (i - 2 >= 0) cnt[i - 2] = 0;
            if (i - 1 >= 0) cnt[i - 1] = 0;
            int newMax = max > newA[i] ? max : newA[i];
            newA[400] = newMax;
            int m = recurse (newA, i - 2);
            max = max > m ? max : m;
        }
        if (i != N - 2) {
            if (A[i] == A[i + 2]) {
                change = 0;
                // int newA[401];
                // if (i != 0)
                //     memcpy(newA, A, i * sizeof(int));
                // newA[i] = (A[i] << 1) + A[i + 1];
                // int newMax = max > newA[i] ? max : newA[i];
                // newA[400] = newMax;
                // if (l - i - 3 > 0)
                //     memcpy(&newA[i + 1], &A[i + 3], (l - i - 3) * sizeof(int));
                // int m = recurse (newA, i - 2, l - 2);
                // max = max > m ? max : m;
                int newA[401];
                memcpy(newA, A, 401 * sizeof(int));
                newA[i] = (A[i] << 1) + newA[i + 1];
                newA[i + 1] = -1;
                newA[i + 2] = -1;
                if (i - 2 >= 0) cnt[i - 2] = 0;
                if (i - 1 >= 0) cnt[i - 1] = 0;
                int newMax = max > newA[i] ? max : newA[i];
                newA[400] = newMax;
                int m = recurse (newA, i - 2);
                max = max > m ? max : m;
            }
        }
        if (change) 
            cnt[i] = 1;
    }
    // printf("%d\n", max);
    return max;
}

int main() {
    scanf("%d", &N);
    int max = 0;
    for (int i = 0; i < N; i ++) {
        int s;
        scanf("%d", &s);
        riceballs[i] = s;
        max = max > s ? max : s;
    }
    riceballs[400] = max;
    printf("%d\n", recurse(riceballs, 0));
    return 0;
}