#include <stdio.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <queue>
#include <string.h>
using namespace std;

int N, M;
unordered_set<int> P;
unordered_set<int> C;
vector<int> map[100001];
int V[100001];

long encode (int a, int b) {
    return a < b ? a * 1000000 + b : b * 1000000 + a;
}

int main() {
    scanf("%d %d", &N, &M);
    for (int i = 0; i < M; i ++) {
        int p;
        scanf("%d", &p);
        P.emplace(p);
    }
    for (int i = 1; i < N; i ++) {
        int a, b;
        scanf("%d %d", &a, &b);
        map[a].push_back(b);
        map[b].push_back(a);
        // C.emplace(encode(a, b));
        // if (a < b) C.emplace(make_pair(a, b));
        // else C.emplace(make_pair(b, a));
    }
    // printf("Input Done\n");

    queue<int> Q;
    Q.emplace(*P.begin());
    V[Q.front()] = 1;

    int next = Q.front();
    while (!Q.empty()) {
        int cur = Q.front();
        Q.pop();
        vector<int> neighbour = map[cur];
        for (int i : neighbour) {
            if (V[i] == 0) {
                Q.emplace(i);
                V[i] = V[cur] + 1;
                if (P.count(i) && V[i] > V[next]) next = i;
            }
        }
    }

    memset(V, 0, sizeof(V));

    queue<vector<int>> Q2;
    Q2.emplace(vector<int>());
    Q2.back().push_back(next);
    V[next] = 1;

    long time = 0;
    vector<int> longest;
    while (!Q2.empty()) {
        int cur = Q2.front().back();
        vector<int> path = Q2.front();
        Q2.pop();
        vector<int> neighbour = map[cur];
        for (int i : neighbour) {
            if (V[i] == 0) {
                Q2.emplace(path);
                Q2.back().push_back(i);
                V[i] = V[cur] + 1;
                if (P.count(i)) {
                    if (V[i] > longest.size()) longest = Q2.back();
                    time += 2;
                    // C.erase(encode(i, path.back()));
                    C.emplace(encode(i, path.back()));
                    // printf("Begin: %d %d\n", i, path.back());
                    for (int j = path.size() - 1; j > 0; j --) {
                        int a = path[j], b = path[j - 1];
                        // if (C.count(make_pair(a, b))) {
                        if (!C.count(encode(a, b))) {
                            time += 2;
                            // printf("%d %d\n", a, b);
                            // C.erase(encode(a, b));
                            C.emplace(encode(a, b));
                        }
                        else break;
                    }
                }
            }
        }
    }
    // printf("%d %d\n", time, longest.size());
    printf("%ld\n", time - longest.size() + 1);
}