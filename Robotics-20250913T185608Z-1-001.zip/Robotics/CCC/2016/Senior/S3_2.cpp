#include <stdio.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <queue>
#include <string.h>
using namespace std;

int N, M;
unordered_set<int> P;
vector<int> map[100000];
int V[100000];

int main() {
    scanf("%d %d", &N, &M);
    for (int i = 0; i < M; i ++) {
        int p;
        scanf("%d", &p);
        P.emplace(p);
    }
    for (int i = 1; i < N; i ++) {
        int a, b;
        scanf("%d %d", &a, &b);
        map[a].push_back(b);
        map[b].push_back(a);
    }
    // printf("Input Done\n");

    queue<int> Q;
    Q.emplace(*P.begin());
    V[Q.front()] = 1;

    int next = Q.front();
    while (!Q.empty()) {
        int cur = Q.front();
        Q.pop();
        vector<int> neighbour = map[cur];
        for (int i : neighbour) {
            if (V[i] == 0) {
                Q.emplace(i);
                V[i] = V[cur] + 1;
                if (P.count(i) && V[i] > V[next]) next = i;
            }
        }
    }
    // printf("First BFS Done\n");

    memset(V, 0, sizeof(V));

    queue<pair<int, unordered_set<int>>> Q2;
    Q2.emplace(make_pair(next, unordered_set<int>()));
    Q2.back().second.emplace(next);
    V[next] = 1;

    unordered_set<int> longest;
    while (!Q2.empty()) {
        int cur = Q2.front().first;
        unordered_set<int> path = Q2.front().second;
        Q2.pop();
        vector<int> neighbour = map[cur];
        for (int i : neighbour) {
            if (V[i] == 0) {
                Q2.emplace(make_pair(i, path));
                Q2.back().second.emplace(i);
                V[i] = V[cur] + 1;
                if (P.count(i) && V[i] > longest.size()) longest = Q2.back().second;
            }
        }
    }
    // printf("Second BFS Done\n");

    memset(V, 0, sizeof(V));

    for (int i : longest) 
        V[i] = 1;

    int time = longest.size() - 1;
    for (int i : P) {
        if (V[i] == 0) {
            queue<int> Q3;
            Q3.emplace(i);
            V[i] = 1;
            while(!Q3.empty()) {
                int cur = Q3.front();
                Q3.pop();
                vector<int> neighbour = map[cur];
                for (int j : neighbour) {
                    if (V[j] == 0) {
                        Q3.emplace(j);
                        V[j] = V[cur] + 1;
                    }
                    else {
                        time += V[cur] * 2;
                        goto end;
                    }
                }
            }
            end:;
        }
    }
    printf("%d\n", time);
}