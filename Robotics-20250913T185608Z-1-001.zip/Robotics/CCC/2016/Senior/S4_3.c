#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int riceballs[400];
int maxA[400];
int N;

int update(int A[400], int i, int l) {
    for (int j = 0; j < l; j ++) {
        printf("%d ", A[j]);
    }
    printf("\n");
    int max = A[i];
    if (i > 0 && A[i] == A[i - 1]) {
        int newA[400];
        if (i - 1 != 0)
            memcpy(newA, A, (i - 1) * sizeof(int));
        newA[i - 1] = (A[i - 1] << 1);
        if (l - i - 1 > 0)
            memcpy(&newA[i], &A[i + 1], (l - i - 1) * sizeof(int));
        int v = update (newA, i - 1, l - 1);
        max = max > v ? max : v; 
    }
    if (i > 1 && A[i] == A[i - 2]) {
        int newA[400];
        if (i - 2 != 0)
            memcpy(newA, A, (i - 2) * sizeof(int));
        newA[i - 2] = (A[i - 2] << 1) + A[i - 1];
        if (l - i - 1 > 0)
            memcpy(&newA[i - 1], &A[i + 1], (l - i - 1) * sizeof(int));
        int v = update (newA, i - 2, l - 2);
        max = max > v ? max : v; 
    }
    if (i < l - 1 && A[i] == A[i + 1]) {
        int newA[400];
        if (i != 0)
            memcpy(newA, A, i * sizeof(int));
        newA[i] = (A[i] << 1);
        if (l - i - 2 > 0)
            memcpy(&newA[i + 1], &A[i + 2], (l - i - 2) * sizeof(int));
        int v = update (newA, i, l - 1);
        max = max > v ? max : v;
    }
    if (i != l - 2 && A[i] == A[i + 2]) {
        int newA[400];
        if (i != 0)
            memcpy(newA, A, i * sizeof(int));
        newA[i] = (A[i] << 1) + A[i + 1];
        if (l - i - 3 > 0)
            memcpy(&newA[i + 1], &A[i + 3], (l - i - 3) * sizeof(int));
        int v = update (newA, i, l - 2);
        max = max > v ? max : v;   
    }
    return max;
}

int main() {
    scanf("%d", &N);
    for (int i = 0; i < N; i ++) 
        scanf("%d", &riceballs[i]);
    int max = 0;
    for (int i = 0; i < N - 1; i ++) {
        maxA[i] = riceballs[i];
        if (riceballs[i] == riceballs[i + 1]) {
            int newA[400];
            if (i != 0)
                memcpy(newA, riceballs, i * sizeof(int));
            newA[i] = (riceballs[i] << 1);
            if (N - i - 2 > 0)
                memcpy(&newA[i + 1], &riceballs[i + 2], (N - i - 2) * sizeof(int));
            maxA[i] = update (newA, i, N - 1);
        }
        if (i != N - 2) {
            if (riceballs[i] == riceballs[i + 2]) {
                int newA[400];
                if (i != 0)
                    memcpy(newA, riceballs, i * sizeof(int));
                newA[i] = (riceballs[i] << 1) + riceballs[i + 1];
                if (N - i - 3 > 0)
                    memcpy(&newA[i + 1], &riceballs[i + 3], (N - i - 3) * sizeof(int));
                maxA[i] = update (newA, i, N - 2);
            }
        }
        max = max > maxA[i] ? max : maxA[i];
    }
    printf("%d\n", max);
    return 0;
}