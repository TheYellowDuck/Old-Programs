#include <stdio.h>
#include <unordered_map>
using namespace std;

int N, M;
int P[100000];
vector<pair<int, int>> map[100000];
int pho[100000];

void updateConnection(int a, int b, int cost) {
    vector<pair<int, int>> C = map[b];
    for (auto i : C) {
        if (i.first == a) continue;
        if (P[i.first]) {
            map[a].insert(make_pair(i.first, cost + i.second));
            map[i.first].insert(make_pair(a, cost + i.second));
        }
        else 
            updateConnection(a, i.first, cost + i.second);
    }
}

int main() {
    scanf("%d %d", &N, &M);
    for (int i = 0; i < M; i ++) {
        int p;
        scanf("%d", &p);
        // P[i] = p;
        P[p] = 1;
        pho[i] = p;
    }

    for (int i = 0; i < N; i ++) {
        int a, b;
        scanf("%d %d", &a, &b);
        map[a].insert(make_pair(b, 1));
        map[b].insert(make_pair(a, 1));
        if (P[a] && !P[b]) 
            updateConnection(a, b, 1);
        if (P[b] && !P[a])
            updateConnection(b, a, 1);
    }

    priority_queue<pair<int, vector<int>>> Q;
    

}