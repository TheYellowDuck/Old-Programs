#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int N, K;
int A[3000][3000];
int V[3000][3000];
// int S[4501500];
int I[4501500];
int size = 0;
long sum = 0;

int binarysearch (int val, int l, int r) {
    if (r < 0) return -1;
    if (A[I[r] / 10000][I[r] % 10000] < val) return r;
    else if (r == 0) return -1;

    int ans = -1;
    while (l <= r) {
        int m = (l + r) / 2;
        if (A[I[m] / 10000][I[m] % 10000] < val) {
            ans = m;
            l = m + 1;
        }
        else r = m - 1;
    }
    return ans;
}

int main() { 
    scanf("%d %d", &N, &K);
    for (int i = 0; i < N; i ++) {
        for (int j = 0; j <= i; j ++) {
            int v;
            scanf("%d", &v);
            A[i][j] = v;
            int in = binarysearch(v, 0, size - 1) + 1;
            if (size != in) {
                // memmove(&S[in + 1], &S[in], (size - in) * sizeof(int));
                memmove(&I[in + 1], &I[in], (size - in) * sizeof(int));
            }
            // S[in] = v;
            I[in] = i * 10000 + j;
            size ++;
        }
    }
    for (int t = size - 1; t >= 0; t --) {
        int x = I[t] / 10000, y = I[t] % 10000;
        // printf("Index: %d %d\n", x, y);
        int a = x - K + 1, b = y - K + 1, c = x + K - 1, d = y + K - 1;
        
        // for (int i = (a > 0 ? a : 0); i <= x; i ++) {
        //     for (int j = (b > 0 ? b : 0); j <= y && j <= i; j ++) {
        //         printf("%d %d\n", i, j);
        //         if (!V[i][j]) {
        //             sum += A[x][y];
        //             V[i][j] = 1;
        //         }
        //     }
        // }
        // for (int i = x; i <= c && i < N; i ++) {
        //     for (int j = y; j <= d && j <= i; j ++) {
        //         printf("%d %d\n", i, j);
        //         if (!V[i][j]) {
        //             sum += A[x][y];
        //             V[i][j] = 1;
        //         }
        //     }
        // }
        // for (int i = (a > 0 ? a : 0) + 1, count = 0; i < x; i ++, count ++) {
        //     for (int j = y + 1, count2 = 0; j < N && j <= i && count2 <= count; j ++, count2 ++) {
        //         printf("%d %d\n", i, j);
        //         if (!V[i][j]) {
        //             sum += A[x][y];
        //             V[i][j] = 1;
        //         }
        //     }
        // }
        // for (int i = x + 1; i < c && i < N; i ++) {
        //     for (int j = (b > 0 ? b : 0) + 1; j < y && j <= i; j ++) {
        //         printf("%d %d\n", i, j);
        //         if (!V[i][j]) {
        //             sum += A[x][y];
        //             V[i][j] = 1;
        //         }
        //     }
        // }
        printf("Sum: %ld\n", sum);
    }
    printf("%ld\n", sum);
    return 0;
}