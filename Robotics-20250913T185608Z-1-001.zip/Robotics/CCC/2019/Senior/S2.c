#include <stdio.h>
#include <stdlib.h>

int calprimes[(long) 2e6];
long primes[(long) 1e6];
long indexi = 0;

void calculatePrimes() {
    for (long i = 2; i < 2e6; i ++) {
        if (!calprimes[i]) {
            primes[indexi ++] = i;
            // printf("%d\n", i);
        }
        for (long j = 2; i * j < 2e6; j ++) 
            calprimes[(long) i * j] = 1;
    }
}

int main() {
    calculatePrimes();
    int T;
    scanf("%d", &T);
    for (int i = 0; i < T; i ++) {
        long N;
        scanf("%ld", &N);
        N *= 2;
        for (int j = 0; j < indexi; j ++) {
            if (!calprimes[(long) (N - primes[j])]) {
                printf("%ld %ld\n", (long) primes[j], (long) (N - primes[j]));
                break;
            }
        }
    }
    return 0;
}