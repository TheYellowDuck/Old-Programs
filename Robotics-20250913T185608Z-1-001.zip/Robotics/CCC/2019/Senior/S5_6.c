#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int N, K;
int A[3001][3001];
// int V[3001][3001];
// int mem[3001][3001][3001];

int findmax (int x, int y, int k) {
    if (k == 1) return A[x][y];
    int newk = k * 2 / 3;
    if (newk == k) newk --;
    int a = findmax(x, y, newk);
    int b = findmax(x + k - newk, y, newk);
    int c = findmax(x + k - newk, y + k - newk, newk);
    // printf("%d %d %d\n", a, b, c);
    return a > b ? a > c ? a : c : b > c ? b : c;
}

int main() { 
    // memset(V, -1, sizeof(V));
    scanf("%d %d", &N, &K);
    long sum = 0;
    for (int i = 0; i < N; i ++) {
        for (int j = 0; j <= i; j ++) {
            int v;
            scanf("%d", &v);
            A[i][j] = v;
        }
    }
    int k;
    for (k = 1; k < (K + 1) * 2 / 3 - 1; k = /*ceil((double) k * 3 / 2)*/ /*(k + 1) / 2 + k*/) {
        for (int i = 0; i <= N - k; i ++) {
            for (int j = 0; j <= i; j ++) {
                A[i][j] = A[i][j] > A[i + ((k + 1) / 2)][j] ? A[i][j] : A[i + ((k + 1) / 2)][j];
                A[i][j] = A[i][j] > A[i + ((k + 1) / 2)][j + ((k + 1) / 2)] ? A[i][j] : A[i + ((k + 1) / 2)][j + ((k + 1) / 2)];
                // sum += findmax(i, j, K);
                // printf ("%ld\n", sum);
            }
        }
    }
    for (int i = 0; i <= N - K; i ++) {
        for (int j = 0; j <= i; j ++) {
            if (k == (K + 1) * 2 / 3 - 1) {
                A[i][j] = A[i][j] > A[i + ((k + 1) / 2)][j] ? A[i][j] : A[i + ((k + 1) / 2)][j];
                A[i][j] = A[i][j] > A[i + ((k + 1) / 2)][j + ((k + 1) / 2)] ? A[i][j] : A[i + ((k + 1) / 2)][j + ((k + 1) / 2)];
            }
            else {
                A[i][j] = A[i][j] > A[i + ((k + 1) / 2) - 1][j] ? A[i][j] : A[i + ((k + 1) / 2) - 1][j];
                A[i][j] = A[i][j] > A[i + ((k + 1) / 2) - 1][j + ((k + 1) / 2) - 1] ? A[i][j] : A[i + ((k + 1) / 2) - 1][j + ((k + 1) / 2) - 1];
            }
            sum += A[i][j];
            // printf ("%ld\n", sum);
        }
    }


    // for (int i = 0; i <= N - K; i ++) {
    //     for (int j = 0; j <= i; j ++) {
    //         sum += findmax(i, j, K);
    //         // printf ("%ld\n", sum);
    //     }
    // }
    printf("%ld\n", sum);
    return 0;
}