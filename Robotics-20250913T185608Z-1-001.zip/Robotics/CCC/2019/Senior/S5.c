#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int T[3000][3001];
int V[3000][3001];
int H[3000][3001];
int N, K;

static inline int binarysearch (int* A, int l, int r, int n) {
    if (r <= 1) return 1;
    if (n < A[r]) return r + 1;
    int ans = 0;
    while (l <= r) {
        int m = (l + r) / 2;
        if (n >= A[m]) r = m - 1;
        else {
            ans = m;
            l = m + 1;
        }
    }
    return ans + 1;
}

static inline void update (int* A, int n, int d, int x, int y) {
    int addi = binarysearch(A, 1, A[0] + 1, n);
    // for (int k = 0; k <= A[0]; k ++) {
    //     printf ("%d ", A[k]);
    // }
    // printf("%d before\n", addi);
    if (A[0] >= addi) {
        memmove(&A[addi + 1], &A[addi], (A[0] - addi + 1) * sizeof(int));
        // printf("moving ");
        // for (int k = 0; k <= A[0] + 1; k ++) {
        //     printf ("%d ", A[k]);
        // }
        // printf("\n");
    }
    A[addi] = n;
    A[0] ++;
    // for (int k = 0; k <= A[0]; k ++) {
    //     printf ("%d ", A[k]);
    // }
    // printf("%d update%d %d %d\n", addi, d, x, y);

    if (A[0] > K) {
        // printf("removing: %d\n", d ? T[x - K][y] : T[x][y + K]);
        int removei = binarysearch (A, 1, A[0] + 1, d ? T[x - K][y] : T[x][y + K]);
        if (A[0] > removei)
            memmove(&A[removei], &A[removei + 1], (A[0] - removei) * sizeof(int));
        A[A[0]] = 0;
        A[0] --;
    }
}

int main() {
    scanf("%d %d", &N, &K);
    long sum = 0;
    for (int i = 0; i < N; i ++) {
        for (int j = 0; j <= i; j ++) {
            int v;
            scanf("%d", &v);
            T[i][i - j] = v;
            update(&H[i][0], v, 0, i, i - j);
            update(&V[i - j][0], v, 1, i, i - j);
            if (j >= K - 1) {
                int max = 0;
                max = (max >= H[i][1] ? max : H[i][1]);
                // for (int k = 0; k <= H[i][0]; k ++) {
                //     printf ("%d ", H[i][k]);
                // }
                // printf("%d\n", max);
                max = (max >= V[i - j][1] ? max : V[i - j][1]);
                // for (int k = 0; k <= V[i - j][0]; k ++) {
                //     printf ("%d ", V[i - j][k]);
                // }
                // printf("%d\n", max);
                sum += max;
            }
            // printf("Sum: %ld\n", sum);
        }
    }
    printf("%ld\n", sum);
    return 0;
}