#include <stdio.h>
#include <stdlib.h>

int N, K;
int A[3001][3001];

int main() { 
    scanf("%d %d", &N, &K);
    long sum = 0;
    for (int i = 0; i < N; i ++) {
        for (int j = 0; j <= i; j ++) {
            int v;
            scanf("%d", &v);
            A[i][j] = v;
            if (i >= K - 1 && j >= K - 1) {
                int max = 0;
                for (int k = i - K + 1, countk = 0; countk < K; k ++, countk ++) {
                    for (int l = j - K + 1, countl = 0; countl <= countk ; l ++, countl ++) {
                        // printf("%d %d\n", k, l);
                        max = max > A[k][l] ? max : A[k][l];
                    }
                }
                sum += max;
                // printf ("SUM: %ld %d\n", sum, max);
            }
        }
    }
    printf("%ld\n", sum);
    return 0;
}