#include <stdio.h>
#include <stdlib.h>

int N, K;
int A[3001][3001];

int main() { 
    scanf("%d %d", &N, &K);
    long sum = 0;
    int max = 0;
    for (int i = 0; i < N; i ++) {
        for (int j = 0; j <= i; j ++) {
            int v;
            scanf("%d", &v);
            A[i][j] = v;
            max = max > v ? max : v;
        }
    }
    if (K == 1) 
        for (int i = 0; i < N; i ++) 
            for (int j = 0; j <= i; j ++)
                sum += A[i][j];
    else if (K == N) sum = max;
    else {
        for (int i = 1; i < K; i ++) {
            for (int j = 0; j < N - i; j ++) {
                for (int k = 0; k <= j; k ++) {
                    A[j][k] = A[j][k] > A[j + 1][k] ? A[j][k] : A[j + 1][k];
                    A[j][k] = A[j][k] > A[j + 1][k + 1] ? A[j][k] : A[j + 1][k + 1];
                    if (i == K - 1) sum += A[j][k];
                }
            }
        }
    }
    printf("%ld\n", sum);
    return 0;
}