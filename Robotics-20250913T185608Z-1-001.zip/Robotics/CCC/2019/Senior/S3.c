#include <stdio.h>
#include <stdlib.h>

int grid[3][3];
int v[3][3];
int countx[3];
int county[3];
char in[11];
// void update (int x, int y) {
//     for (int )
// }

int main() { 
    for (int i = 0; i < 3; i ++) {
        for (int j = 0; j < 3; j ++) {
            scanf("%s", &in);
            if (in[0] == 'X') {
                v[i][j] = 1;
                countx[i] ++;
                county[j] ++;
            }
            else grid[i][j] = strtol(in, &in[10], 10);
            // printf("%d\n", grid[i][j]);
        }
    }
    for (int i = 0; i < 3; i ++) {
        if (countx[i] == 1) {
            countx[i] --;
            if (v[i][0]) {
                v[i][0] = 0;
                county[0] --;
                if (grid[i][1] <= grid[i][2]) 
                    grid[i][0] = grid[i][1] - (grid[i][2] - grid[i][1]);
                else
                    grid[i][0] = grid[i][1] + (grid[i][1] - grid[i][2]);
            }
            else if (v[i][1]) {
                v[i][1] = 0;
                county[1] --;
                if (grid[i][0] <= grid[i][2]) 
                    grid[i][1] = grid[i][0] + (grid[i][2] - grid[i][0]) / 2;
                else
                    grid[i][1] = grid[i][2] + (grid[i][0] - grid[i][2]) / 2;
            }
            else {
                v[i][2] = 0;
                county[2] --;
                if (grid[i][0] <= grid[i][1]) 
                    grid[i][2] = grid[i][1] + (grid[i][1] - grid[i][0]);
                else
                    grid[i][2] = grid[i][1] - (grid[i][0] - grid[i][1]);
            }
        }
    }
    return 0;
}