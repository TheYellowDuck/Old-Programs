#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int N, K;
int A[3001][3001];

void findmax (int k) {
    if (k == 1) return;
    int newk = ceil((double) (k + 1) * 2 / 3) - 1;
    findmax(newk);
    for (int i = 0; i <= N - k; i ++) {
        for (int j = 0; j <= i; j ++) {
            A[i][j] = A[i][j] > A[i + k - newk][j] ? A[i][j] : A[i + k - newk][j];
            A[i][j] = A[i][j] > A[i + k - newk][j + k - newk] ? A[i][j] : A[i + k - newk][j + k - newk];
        }
    }
    return;
}

int main() { 
    scanf("%d %d", &N, &K);
    long sum = 0;
    for (int i = 0; i < N; i ++) {
        for (int j = 0; j <= i; j ++) {
            int v;
            scanf("%d", &v);
            A[i][j] = v;
        }
    }

    findmax(K);

    for (int i = 0; i <= N - K; i ++) {
        for (int j = 0; j <= i; j ++) {
            sum += A[i][j];
        }
    }
    printf("%ld\n", sum);
    return 0;
}