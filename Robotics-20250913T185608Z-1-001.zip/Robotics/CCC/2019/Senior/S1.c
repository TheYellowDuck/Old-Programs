#include <stdio.h>
#include <stdlib.h>

int main() {
    int H = 0, V = 0;
    char c;
    do {
        scanf("%c", &c);
        if (c == 'H') H = !H;
        else if (c == 'V') V = !V;
    }
    while (c != '\n');
    if (H == 0 && V == 0) printf("1 2\n3 4");
    else if (H == 1 && V == 0) printf("3 4\n1 2");
    else if (H == 0 && V == 1) printf("2 1\n4 3");
    else printf("4 3\n2 1");
    return 0;
}