#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
uint64_t rules[3][2];

uint64_t convertint(char *a) {
    uint64_t num = 1;
    for (int i = 0; i < 51; i ++) {
        if (a[i] == '\0') break;
        num = (num << 1) + (a[i] - 'A');
        // num = num * 10 + a[j] - 'A';
    }
    // printf("%lld\n", num);
    return num;
}

uint64_t queue1[5000], queue2[5000];
int iaccess1 = 0, iadd1 = 0;
int iaccess2 = 0, iadd2 = 0;

int main() {
    for (int i = 0 ; i < 3; i ++) {
        char in1[6], in2[6];
        scanf("%s %s", &in1, &in2);
        rules[i][0] = convertint(in1);
        rules[i][1] = convertint(in2);
    }
    int S = 0;
    char in1[6], in2[51];
    scanf("%d %s %s", &S, &in1, &in2);
    uint64_t I = convertint(in1);
    uint64_t F = convertint(in2);
    queue1[iadd1 ++] = I;
    queue2[iadd2 ++] = F;
    return 0;
}