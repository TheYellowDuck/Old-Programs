#include <stdio.h>
#include <stdlib.h>

int main() {
    int N;
    scanf("%d\n", &N);
    for (int i = 0; i < N; i ++) {
        char c, prev = '\0';
        int count = 1;
        do {
            scanf("%c", &c);
            if (prev == c)
                count ++;
            else if (prev != '\0') {
                printf("%d %c ", count, prev);
                count = 1;
            }
            prev = c;
        }
        while (c != '\n');
        printf("\n");
    }
    return 0;
}