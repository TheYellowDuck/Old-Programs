#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <Windows.h>

uint64_t rules[3][2];
uint64_t masks[3][2];

uint64_t convertint(char *a) {
    uint64_t num = 1;
    for (int i = 0; i < 51; i ++) {
        if (a[i] == '\0') break;
        num = (num << 1) + (a[i] - 'A');
        // num = num * 10 + a[j] - 'A';
    }
    // printf("%lld\n", num);
    return num;
}
char *convertstr(uint64_t a) {
    static char str[1000];
    for (int i = 0; a > 1; i ++) {
        str[i] = (1 & a) + 'A';
        a = (a >> 1);
        str[i + 1] = '\0';
        // num = num * 10 + a[j] - 'A';
    }
    
    // printf("%lld\n", num);
    return str;
}

int recurse(int S, int l, uint64_t I, uint64_t F) {
    if (S == 0) {
        // printf("incurse %d %lld %lld\n", S, I, F);
        if (I == F) {
            printf("incurse %d %lld %lld\n", S, I, F);
            return 1;
        }
        return 0;
    }
    uint64_t returnval = 0;
    uint64_t cur = I;
    int t = 0;
    uint64_t add = 0;
    for (int i = 0; cur > 0; i ++) {
        for (int j = 0; j < 3; j ++) {
            // int numl = floor(log10(abs(rules[j]))) + 1;
            printf("%d %ld %ld\n", j, cur, rules[j][1]);
            if (cur & rules[j][1] == rules[j][1]) {
                printf("%d %ld %ld ", j, cur, rules[j][1]);
                uint64_t temp = cur;
                int nl = l;
                uint64_t rule = rules[j][1];
                while (rule > 1) {
                    temp = (temp >> 1);
                    rule = (rule >> 1);
                    nl --;
                }
                rule = rules[j][0];
                int t2 = 0;
                uint64_t add2 = 0;
                while (rule > 1) {
                    t2 ++;
                    temp = (temp << 1);
                    rule = (rule >> 1);
                    add2 = (add2 << 1) + 1;
                    nl ++;
                }
                printf("%d ", temp);
                temp = ((temp | (rules[j][0] & add2)) << t) | (I & add);
                printf("%ld %ld %d %d\n", temp, rules[j][0], t, t2);
                Sleep(5000);
                returnval = (returnval | recurse(S - 1, nl, temp, F));
                if (returnval) {
                    printf ("%d %d %s\n", j + 1, nl - (t + t2), convertstr(I));
                    goto returnplace;
                }
            }
        }
        // cur /= 10;
        add = (add << 1) + 1;
        cur = (cur >> 1);
        t ++;
    }
    returnplace:;
    return returnval;
}

int main() {
    for (int i = 0 ; i < 3; i ++) {
        char in1[6], in2[6];
        scanf("%s %s", &in1, &in2);
        rules[i][0] = convertint(in1);
        rules[i][1] = convertint(in2);
    }
    int S = 0;
    char in1[6], in2[51];
    scanf("%d %s %s", &S, &in1, &in2);
    uint64_t I = convertint(in1);
    uint64_t F = convertint(in2);
    uint64_t temp = F;
    int l = 0;
    while (temp > 0) {
        l ++;
        temp = (temp >> 1);
    }
    printf("%d %d\n", I, F);
    recurse(S, l, F, I);
    return 0;
}