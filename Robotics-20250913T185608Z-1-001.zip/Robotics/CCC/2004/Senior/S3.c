#include <stdio.h>
#include <stdlib.h>

int spreadsheet[10][9];
int done[10][9];
int update[10][9][91];

// static inline void getref(int ref, int* row, int* col) {
//     *col = ref%10;
//     *row = ref/10;
// }
static inline void updater(int i, int j) {
    for (int k = 1; k <= update[i][j][0]; k ++) {
        int x = update[i][j][k] / 10;
        int y = update[i][j][k] % 10;
        spreadsheet[x][y] += spreadsheet[i][j];
        done[x][y] ++;
        if (done[x][y] == 1) updater(x, y);
    }

}

int main() {
    
    for (int i = 0; i < 10; i ++) {
        for (int j = 0; j < 9; j ++) {
            done[i][j] ++;
            char in[40];
            scanf("%s", in);
            if (in[0] >= '0' && in[0] <='9') {
                sscanf(in, "%d", &spreadsheet[i][j]);
                updater(i, j);
            }
            else {
                for (int k = 0; k < 40 && in[k] != '\0'; k ++) {
                    if (in[k] != '+') {
                        int x = (in[k ++] - 'A');
                        int y = (in[k] - '1');
                        if (done[x][y] == 1) 
                            spreadsheet[i][j] += spreadsheet[x][y];
                        else {
                            update[x][y][++ update[x][y][0]] = i * 10 + j;
                            done[i][j] --;
                        }
                    }
                }
                if (done[i][j] == 1) updater(i, j);
            }
            // for (int n = 0; n < 10; n ++) {
            //     for (int m = 0; m < 9; m ++) {
            //         printf ("{%d %d} ", done[n][m], spreadsheet[n][m]);
            //     }
            //     printf("\n");
            // }
            // printf("\n");
        }
    }
    
    for (int i = 0; i < 10; i ++) {
        for (int j = 0; j < 9; j ++) {
            if (done[i][j] == 1) printf ("%d ", spreadsheet[i][j]);
            else printf("* ");
        }
        printf("\n");
    }

    return 0;
}