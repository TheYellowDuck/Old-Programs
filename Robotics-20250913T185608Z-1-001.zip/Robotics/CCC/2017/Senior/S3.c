#include <stdio.h>
#include <stdlib.h>

int N;
int length[2001];
int lengths[4001];
int maxl = -1, heights = 0; 

int main() { 
    scanf("%d", &N);
    for (int i = 0; i < N; i ++) {
        int v;
        scanf("%d", &v);
        length[v] ++;
    }
    for (int i = 1; i <= 2000; i ++) {
        if (!length[i]) continue;
        lengths[2 * i] += length[i] / 2;
        if (lengths[2 * i] > maxl) {
            maxl = lengths[2 * i];
            heights = 1;
        }
        else if (lengths[2 * i] == maxl) heights ++;
        for (int j = i + 1; j <= 2000; j ++) {
            if (!length[j]) continue;
            lengths[i + j] += length[i] < length[j] ? length[i] : length[j];
            if (lengths[i + j] > maxl) {
                maxl = lengths[i + j];
                heights = 1;
            }
            else if (lengths[i + j] == maxl) heights ++;
        }
    }
    printf("%d %d\n", maxl, heights);
    return 0;
}