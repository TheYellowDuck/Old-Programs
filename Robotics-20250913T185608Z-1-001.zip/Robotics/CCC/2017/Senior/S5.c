#include <stdio.h>
#include <stdlib.h>

typedef struct Node;

typedef struct {
    Node* next;
    int v;
} Node;

typedef struct {
    Node** next;
} SumNode;

int main() {
    int T;
    scanf("%d", &T);
    return 0;
}