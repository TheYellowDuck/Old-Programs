#include <stdio.h>
#include <stdlib.h>

int N;

int main() { 
    scanf("%d", &N);
    printf("%d %d\n", maxl, heights);
    return 0;
}