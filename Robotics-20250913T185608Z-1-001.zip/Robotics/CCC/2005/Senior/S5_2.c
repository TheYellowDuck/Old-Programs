#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int scores[100000];

int main() {
    int T;
    scanf("%d", &T);
    long sum = 0;
    for (int i = 0; i < T; i ++) {
        int score;
        scanf("%d", &score);
        // int ini = binarysearch(0, i, score) + 1;
        int ini = i - 1;
        while (ini >= 0 && scores[ini] <= score) {
            scores[ini + 1] = scores[ini];
            ini --;
        }
        scores[ini + 1] = score;
        sum += ini + 2;
        // printf("%d %d\n", sum, ini + 2);
    }
    printf("%.2lf\n", rint((double)(sum * 100) / T) / 100);
    return 0;
}