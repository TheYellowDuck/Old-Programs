#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int hash (char *a) {
    int hash = 7;
    for (int i = 0; i < 10; i++) {
        if (a[i] == '\0') break;
        hash = hash * 31 + a[i];
    }
    return hash;
}

int people[MAX];
int depth[MAX];
int set[MAX];
int access = 0;

int binarysearch (int l, int r, int v) {
    if (r == 0) return -1;
    if (v > set[r - 1]) return r - 1;
    int ans = -1;
    while (l <= r) {
        int m = (l + r) / 2;
        if (set[m] >= v) r = m - 1;
        else {
            ans = m;
            l = m + 1;
        }
    }
    return ans;
}

int add (int v) {
    int ini = binarysearch (0, access, v) + 1;
    // printf("%d\n", ini);
    if (set[ini] == v) return -1;
    for (int i = access; i > ini; i --)
    set[i] = set[i - 1];
    set[ini] = v;
    access ++;
    return 1;
}

int max (int a, int b) {
    if (a >= b) return a;
    return b;
}

int main() {
    int L;
    scanf("%d", &L);
    for (int i = 0; i < L; i ++) {
        int N;
        access = 0;
        scanf("%d", &N);
        for (int j = N - 1; j >= 0; j --) {
            char c[10];
            scanf("%s", &c);
            int h = hash(c);
            people[j] = h;
        }

        int m = 0;
        depth[0] = 0;
        add(people[0]);
        for (int j = 1; j < N; j ++) {
            int r = add(people[j]);
            depth[j] = depth[j - 1] + r;
            m = max(m, depth[j]);
        }

        // for (int sim = 0; sim <= N; sim ++) {
        //     printf("%d ", people[sim]);
        // }
        // printf("\n");
        // for (int sim = 0; sim <= N; sim ++) {
        //     printf("%d ", depth[sim]);
        // }
        // printf("\n");
        printf("%d\n", N * 10 - m * 20);
    }
    return 0;
}