#include <stdio.h>
#include <stdlib.h>

int matrix [1024][1024];
int temp [1024][1024];
int R, C;
int Csum [1024];
int maxV = INT_MIN, minV = INT_MAX;
int maxR = INT_MIN, minR = INT_MAX;
int maxC = INT_MIN, minC = INT_MAX;

int max (int a, int b) {
    if (a >= b) return a;
    return b;
}
int min (int a, int b) {
    if (a <= b) return a;
    return b;
}

int main() {
    int N;
    scanf("%d", &N);
    if (0 < N) {
        scanf("%d %d", &R, &C);
        for (int i = 0; i < R; i ++) {
            for (int j = 0; j < C; j ++) {
                scanf("%d", &matrix[i][j]);
                temp[i][j] = matrix[i][j];
                // printf("%d ", matrix[i][j]);
            }
            // printf("\n");
        }
    }
    for (int t = 1; t < N; t ++) {
        int r, c;
        scanf("%d %d", &r, &c);
        for (int i = 0; i < r; i ++) {
            for (int j = 0; j < c; j ++) {
                int v;
                scanf("%d", &v);
                for (int n = R - 1; n >= 0; n --) {
                    for (int m = C - 1; m >= 0; m --) {
                        matrix[n * r + i][m * c + j] = temp[n][m] * v;
                        // printf("%d %d %d %d %d %d %d %d %d %d\n", n, m, r, c, i, j, n * r + i, m * c + j, matrix[n][m], v);
                    }
                }
            }
        }
        R = R * r;
        C = C * c;
        for (int i = 0; i < R; i ++) {
            for (int j = 0; j < C; j ++) {
                temp[i][j] = matrix[i][j];
            }
            // printf("\n");
        }
        // printf("\n");
    }
    for (int i = 0; i < R; i ++) {
        int sum = 0;
        for (int j = 0; j < C; j ++) {
            // printf("%d ", matrix[i][j]);
            maxV = max (maxV, matrix[i][j]);
            minV = min (minV, matrix[i][j]);
            sum += matrix[i][j];
            Csum[j] += matrix[i][j];
        }
        maxR = max (maxR, sum);
        minR = min (minR, sum);
        // printf("\n");
    }
    for (int i = 0; i < C; i ++) {
        maxC = max (maxC, Csum[i]);
        minC = min (minC, Csum[i]);
    }
    printf("%d\n%d\n%d\n%d\n%d\n%d\n", maxV, minV, maxR, minR, maxC, minC);
    return 0;
}