#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int scores[100000];
int* ini;
// int count[100000];

// int binarysearch(int l, int r, int n) {
//     if (r == 0) return -1;
//     if (n < scores[r - 1]) return r - 1;
//     int ans = -1;
//     while (l <= r) {
//         int m = (l + r) / 2;
//         if (n >= scores[m]) r = m - 1;
//         else {
//             ans = m;
//             l = m + 1;
//         }
//     }
//     return ans;
// }

int compare (const void * a, const void * b) {
    if (*(int*)a >= *(int*)b) return -1;
    else {
        ini = (int *) b;
        // printf("find pointer: %d %d\n", *ini, ini);
        return 1;
    }
}

int main() {
    int T;
    scanf("%d", &T);
    long sum = 0;
    for (int i = 0; i < T; i ++) {
        int score;
        scanf("%d", &score);
        ini = &scores[-1];
        // binarysearch(0, i, score) + 1;
        bsearch(&score, scores, i, sizeof(int), compare);
        // printf("%d %d\n", *ini, ini);
        int inin = ini - &scores[0] + 1;
        memmove (&scores[inin + 1], &scores[inin], sizeof(int) * (i - inin));
        scores[inin] = score;
        sum += inin + 1;
        // printf("%d %d\n", sum, inin + 1);
    }
    printf("%.2lf\n", rint((double)(sum * 100) / T) / 100);
    return 0;
}