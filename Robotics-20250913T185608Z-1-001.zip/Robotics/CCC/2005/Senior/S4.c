#include <stdio.h>
#include <stdlib.h>

#define MAX 5000

typedef struct {
    int value;
    int count;
} Pair;

int key[MAX];
Pair values[MAX];
int access = 0;

int binarysearch (int l, int r, int v) {
    if (l >= r) return access == 0 ? -1 : key[l] <= v ? l : -1;
    int m = l + (r - l) / 2;
    if (v < key[m]) return binarysearch (l, m, v);
    int ret = binarysearch (m + 1, r, v);
    return ret == -1 ? m : ret;
}

void put(int k, int v) {
    int ini = binarysearch (0, access - 1, k);
    if (key[ini] == k) {
        values[ini].value = v;
        values[ini].count ++;
        return;
    }
    ini ++;
    for (int i = access; i > ini; i --) {
        key[i] = key[i - 1];
        values[i] = values[i - 1];
    }
    key[ini] = k;
    values[ini].value = v;
    values[ini].count = 1;
    access ++;
    return;
}

Pair* get(int k) {
    int ini = binarysearch (0, access - 1, k);
    // printf("%d %d %d\n", k, ini, key[ini]);
    if (ini == -1) return NULL;
    // printf("%d %d\n", &values[ini], key[ini] == k);
    if (key[ini] == k) return &values[ini];
    // printf("NULL\n");
    return NULL;
}

int max (int a, int b) {
    if (a >= b) return a;
    return b;
}

int hash (char *a) {
    int hash = 7;
    for (int i = 0; i < 30; i++) {
        if (a[i] == '\0') break;
        hash = hash * 31 + a[i];
    }
    return hash;
}

int people[MAX];
int height[MAX];

int main() {
    int L;
    scanf("%d", &L);
    // printf("print: %d\n", L);
    for (int i = 0; i < L; i ++) {
        access = 0;
        int N;
        scanf("%d", &N);
        // printf("print: %d\n", N);
        int heighti = 0;
        for (int j = 1; j <= N; j ++) {
            char c[30];
            scanf("%s", &c);
            // printf("print: %s\n", c);
            int h = hash(c);
            Pair *last = get(h);
            height[j] = 0;
            if (last != NULL) {
                int c = last->count;
                if (c != 1)
                    height[j] = height[j - 1] + 1;
            }
            // height[j] += height[j - 1];
            people[j] = j - (last == NULL ? 0 : last->value);
            put(h, j);
        }

        // for (int sim = 0; sim <= N; sim ++) {
        //     printf("%d ", people[sim]);
        // }
        // printf("\n");
        // for (int sim = 0; sim <= N; sim ++) {
        //     printf("%d ", height[sim]);
        // }
        // printf("\n");
        // for (int sim = 0; sim <= N; sim ++) {
        //     printf("%d ", values[sim].count);
        // }
        // printf("\n");

        // printf("calculating depth\n");

        int depth = -1;
        for (int j = N; j > 0;) {
            int gap = people[j];
            for (int k = 1; k < gap; k ++) 
                depth = max(depth, height[j - k] + 1);
            j -= gap;
        }

        printf("%d\n", N * 10 - depth * 20);
    }
    return 0;
}