#include <stdio.h>
#include <stdlib.h>

char command;
int x, y;

int dist[50][50];
// int connections[50][50];
int friends[50];
int fof[50];

int min (int a, int b) {
    if (a == 0) return b;
    if (b == 0) return a;
    return (a < b ? a : b);
}

int main() { 
    scanf("%c", &command);
    while (command != 'q') {
        switch (command) {
            case 'i':
                scanf("%d\n%d", x, y);
                dist[x][y] = 1;
                dist[y][x] = 1;
                // connections[x][y] = 1;
                // connections[y][x] = 1;
                friends[x] ++;
                friends[y] ++;
                for (int i = 0; i < 50; i ++) {
                    int v = min (dist[x][i], dist[y][i] + 1);
                    int v2 = min (dist[x][i] + 1, dist[y][i]);
                    dist[x][i] = v;
                    dist[y][i] = v2;
                    if (v == 2) 
                        fof[x] ++;
                    if (v2 == 2)
                        fof[y] ++;
                }
            break;
            case 'd':
                scanf("%d\n%d", x, y);
                dist[x][y] = 0;
                dist[y][x] = 0;
                friends[x] --;
                friends[y] --;
                // connections[x][y] = 0;
                // connections[y][x] = 0;
                // for (int i = 0; i < 50; i ++) {
                //     if (dist[x][i] == 1) dist[y][i]
                // }
            break;
            case 'n':
                scanf("%d", x);
                printf("%d\n", friends[x]);
            break;
            case 'f':
                scanf("%d", x);
                printf("%d\n", fof[x]);
            break;
            case 's':
                scanf("%d\n%d", x, y);
                if (dist[x][y]) printf("%d\n", dist[x][y]);
                else printf("Not connected\n");
            break;
        }
        scanf("%c", &command);
    }
    return 0;
}