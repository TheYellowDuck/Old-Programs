#include <iostream>
#include <bits/stdc++.h>
#include <cstdio>
using namespace std;

pair<int, int> A[100000];
int N;

bool compare (const pair<int, int> &a, const pair<int, int> &b) {
    return a.first < b.first;
}

int main() {
    scanf("%d", &N);
    for (int i = 0; i < N; i ++) 
        scanf("%d %d", &A[i].first, &A[i].second);
    sort(A, A + N, compare);
    double max = -1;
    for (int i = 1; i < N; i ++) {
        double dif = (double) abs(A[i].second - A[i - 1].second) / (A[i].first - A[i - 1].first);
        max = max > dif ? max : dif;
    }
    printf("%f\n", max);
}