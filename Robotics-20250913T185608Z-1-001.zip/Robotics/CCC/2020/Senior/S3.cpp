// #include <iostream>
#include <string.h>
#include <unordered_set>
#include <stdio.h>
using namespace std;

unordered_set < uint64_t > S;
char H[200001];
int N[26];
int HC[26];

int main() {
    int Nlength = 0;
    while (1) {
        char s;
        scanf("%c", &s);
        if (!(s >= 'a' && s <= 'z')) break;
        N[s - 'a'] ++;
        Nlength ++;
    }
    scanf("%s", H);
    int Hlength = strlen(H);
    if (Hlength < Nlength) {
        printf("0\n");
        return 0;
    }
    uint64_t hash = 0;
    uint64_t pow = 1;
    uint64_t cst = 37;

    for (int i = 0; i < Nlength; i ++) {
        char s = H[i];
        HC[s - 'a'] ++;
        hash = hash * cst + (s - 'a');
        if (i)
            pow *= cst;
    }
    // printf("%lu\n", pow);
    for (int i = Nlength; i <= Hlength; i ++) {
        int match = 1;
        for (int j = 0; j < 26; j ++) {
            if (N[j] != HC[j]) {
                match = 0;
                break;
            }
        }
        if (match) {
            S.emplace(hash);
            // char prints[200001];
            // memcpy(prints, &H[i - Nlength], Nlength * sizeof(char));
            // if (hash == 4172378778 || hash == 1367043114) {
            //     printf("%s %lu\n", prints, hash);
            // }
        }
        HC[H[i - Nlength] - 'a'] --;
        HC[H[i] - 'a'] ++;
        hash -= (H[i - Nlength]  - 'a') * pow;
        hash = hash * cst + (H[i] - 'a');
    }
    printf("%ld\n", S.size());
    return 0;
}