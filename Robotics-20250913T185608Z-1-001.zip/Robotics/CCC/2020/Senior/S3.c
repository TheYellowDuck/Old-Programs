#include <stdio.h>
#include <stdlib.h>

// char N[200001];
char H[200001];
int N[26];
int HC[26];
int count = 0;

int main() {
    int Nlength = 0;
    while (1) {
        char s;
        scanf("%c", &s);
        if (s == '\n') break;
        N[s - 'a'] ++;
        Nlength ++;
    }
    
    return 0;
}