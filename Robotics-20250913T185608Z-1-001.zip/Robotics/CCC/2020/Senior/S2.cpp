#include <iostream>
#include <bits/stdc++.h>
#include <cstdio>
using namespace std;

unordered_map<int, vector<pair<int, int>>> ptg;
// unordered_map<int, vector<int>> ptg;
int A[1001][1001];
unordered_set<int> S;
int M, N;
queue<int> Q;

int main() {
    scanf("%d\n%d", &M, &N);
    for (int i = 1; i <= M; i ++) {
        for (int j = 1; j <= N; j ++) {
            int v;
            scanf("%d", &v);
            // A[i][j] = v;
            if (ptg.count(v)) {
                // auto vect = ptg.find(v);
                // vect->second.push_back(make_pair(i, j));
                ptg.find(v)->second.push_back(make_pair(i, j));
                // ptg.find(v)->second.push_back(i * j);
            }
            else {
                vector<pair<int, int>> vect {make_pair(i, j)};
                // vector<int> vect {i * j};
                ptg.insert(make_pair(v, vect));
            }
        }
    }
    bool found = false;
    Q.push(M*N);
    while (!Q.empty()) {
        int cur = Q.front();
        Q.pop();
        if (ptg.count(cur)) {
            vector<pair<int, int>> vect = ptg.find(cur)->second;
            for (int i = 0; i < vect.size(); i ++) {
                // if (!S.count(vect[i])) {
                if (A[vect[i].first][vect[i].second] == 0) {
                    if (vect[i].first == 1 && vect[i].second == 1) {
                        found = true;
                        goto end;
                    }
                    Q.push(vect[i].first * vect[i].second);
                    A[vect[i].first][vect[i].second] = 1;
                    // vect.erase(vect.begin());
                }
            }
        }
    }
    end:;
    if (found) printf("yes\n");
    else printf("no\n");
}