#include <stdio.h>
#include <stdlib.h>

int people[1000000];
long prob[500000000000];
int burgers[500001];

int main() {
    int N;
    scanf("%d", &N);
    int M = 0;
    for (int i = 0; i < N; i ++) {
        int m;
        scanf("%d", &m);
        people[i] = m;
        if (burgers[m] == 0) M ++;
        burgers[m] ++;
    }
    return 0;
}