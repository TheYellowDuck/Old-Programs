#include <stdio.h>
#include <stdlib.h>
// #include <math.h>

int people[1000000];
int burgers[500001];
double prob[500001];

// static inline long factorial(int n) {
//     long v = 1;
//     for (int i = 2; i <= n; i ++) {
//         v *= i;
//     }
//     return v;
// }

int main() {
    int N;
    scanf("%d", &N);
    // printf("%lf\n", (double) (1 / ((N - 1) + (double) 1 / (exp(1) + 1))));
    int M = 0;
    for (int i = 0; i < N; i ++) {
        int m;
        scanf("%d", &m);
        people[i] = m;
        if (burgers[m] == 0) M ++;
        burgers[m] ++;
    }
    // for (int i = 0; i < M; i ++) 
    //     prob[i] = burgers[i]/N;
    int n = N;
    for (int i = 0; i < N; i ++) {
        prob[people[i]] = (double) burgers[people[i]] / N;


    }
    return 0;
}