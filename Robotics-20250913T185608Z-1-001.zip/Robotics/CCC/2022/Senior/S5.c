#include <stdio.h>
#include <stdlib.h>

struct friend {
    int id;
    struct friend* prev;
    struct friend* next;
}

struct student {
    int id;
    int cost;
    int value;
    struct friend* head;
    struct friend* tail;
}

struct student A[200001];
int count = 0;
int cost = 0;

static inline struct friend* newFriend(int id) {
    struct friend* f = (struct friend*) malloc(sizeof(struct friend));
    f->id = id;
    return f;
}

static inline void add (int a, int b) {
    if (A[a].head == NULL) {
        A[a].head = newFriend(b);
        A[a].tail = A[a].head;
    }
    else {
        A[a].tail->next = newFriend(b);
        A[a].tail = A[a].tail->next;
    }
}

int comparator(const void *p, const void *q) 
{
    int l = ((struct student *)p)->cost;
    int r = ((struct student *)q)->cost; 
    return (l >= r);
}

int main() {
    int N;
    scanf("%d", &N);
    for (int i = 1; i < N; i ++) {
        int x, y;
        scanf("%d %d", x, y);
        add(x, y);
        add(y, x);
    }
    for (int i = 1; i <= N; i ++) {
        A[i].id = i;
        char c;
        scanf("%c", &c);
        A[i].value = c == 'Y';
        count += c == 'N';
    }
    for (int i = 1; i <= N; i ++) {
        int c;
        scanf("%d", &c);
        A[i].cost = c;
    }
    qsort((&A + 1), N, sizeof(struct student), comparator);
    for (int i = 1; i <= N; i ++) {
        
    }
    return 0;
}