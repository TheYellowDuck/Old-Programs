#include <stdio.h>
#include <stdlib.h>

int min(int a, int b) {
    if (a <= b) return a;
    return b;
}
int max(int a, int b) {
    if (a >= b) return a;
    return b;
}
int abs(int a) {
    if (a < 0) return -a;
    return a;
}

int main() {
    int N;
    scanf("%d", &N);
    int T;
    scanf("%d", &T);
    int X[T], Y[T];
    for (int i = 0; i < T; i ++) {
        int x, y;
        scanf("%d %d", &x, &y);
        X[i] = x;
        Y[i] = y;
    }

    int M = 0;
    for (int i = 0; i < T; i ++) {
        for (int j = i + 1; j < T; j ++) {
            int l = min (X[i], X[j]), r = max (X[i], X[j]), u = min (Y[j], Y[j]), d = max (Y[j], Y[j]);
            if (l == r) continue;
            for (int k = j + 1; k < T; k ++) {
                if (!(X[k] > l && X[k] < r)) continue;
                if (!(Y[k] > d || Y[k] < u)) continue;
                if (Y[k] > d) {
                    for (int h = 0; h < T; h ++) {
                        if (!(X[h] <= l && X[h] >= r && Y[h] >= Y[k] && Y[h] <= Y[k] - (r - l))) goto label;
                    }
                    M = max(M, (r - l - 1));
                }
                else {
                    for (int h = 0; h < T; h ++) {
                        if (!(X[h] <= l && X[h] >= r && Y[h] <= Y[k] && Y[h] >= Y[k] + (r - l))) goto label;
                    }
                    M = max(M, (r - l - 1));
                }
                label:;
                printf("%d %d %d %d %d %d %d %d\n", X[i], Y[i], X[j], Y[j], X[k], Y[k], M, r - l - 1);
            // if (X[j] > X[i] || t[j][1] < t[i][1]) continue;
            }
        }
    }
    printf("%d\n", M);
    return 0;
}