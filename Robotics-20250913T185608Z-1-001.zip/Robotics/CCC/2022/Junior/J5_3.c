#include <stdio.h>
#include <stdlib.h>

int min(int a, int b) {
    if (a <= b) return a;
    return b;
}
int max(int a, int b) {
    if (a >= b) return a;
    return b;
}
int abs(int a) {
    if (a < 0) return -a;
    return a;
}

int main() {
    int N;
    scanf("%d", &N);
    int T;
    scanf("%d", &T);
    int X[T + 1], Y[T + 1];
    for (int i = 0; i < T; i ++) {
        int x, y;
        scanf("%d %d", &x, &y);
        X[i] = x;
        Y[i] = y;
    }
    X[T] = 0;
    Y[T] = 0;
    T++;

    int M = 0;
    for (int i = 0; i < T; i ++) {
        int U = X[i];
        for (int j = 0; j < T; j ++) {
            if (i == j && i != T - 1) continue;
            int cur = 500001;
            int L = Y[j];

            for (int k = 0; k < T; k ++) {
                if (k == i || k == j) continue;
                if (X[k] > U && Y[k] > L)
                    cur = min(cur, max(X[k] - U  - 1, Y[k] - L - 1));
            }
            int edge = min(N - U, N - L);
            if (edge < cur)
                cur = edge;
            M = max(M, cur);            
        }
    }
    printf("%d\n", M);
    return 0;
}