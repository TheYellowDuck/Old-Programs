#include <stdio.h>
#include <stdlib.h>

int min(int a, int b, int c) {
    if (a <= b) {
        if (a > c) return c;
        return a;
    }
    if (b > c) return c;
    return b;
}
int max(int a, int b) {
    if (a >= b) return a;
    return b;
}

int pre[500001];
int main() {
    int N;
    scanf("%d", &N);
    int T;
    scanf("%d", &T);
    int t[T][2];
    for (int i = 0; i < T; i ++) {
        int x,
        y;
        scanf("%d %d", &x, &y);
        int index = i;
        for (int j = i - 1; j >= 0; j --) {
            if (t[j][0] > x || (t[j][0] == x && t[j][1] > y)) {
                t[j + 1][0] = t[j][0];
                t[j + 1][1] = t[j][1];
                index = j;
            }
            else
            break;
        }
        t[index][0] = x;
        t[index][1] = y;
    }
    int M = 0;
    int index = 0;
    for (int i = 1; i <= N; i ++) {
        int b = t[index][0] == i;
        int left = 0,
        uleft = 0;
        int tempindex = index;
        for (int j = 1; j <= N; j ++) {
            if (b) {
                for (int k = index; k < T; k ++) {
                    if (t[k][0] == i) {
                        if (t[k][1] == j) {
                            left = 0;
                            uleft = pre[j];
                            pre[j] = 0;
                            goto label;
                        }
                    }
                    else {
                        tempindex = k;
                        break;
                    }
                }
            }
            if (i == 1) {
                pre[j] = 1;
                uleft = 1;
                left = 1;
                M = 1;
                continue;
            }
            left = min(pre[j], left, uleft) + 1;
            uleft = pre[j];
            pre[j] = left;
            M = max(M, left);
            label:;
        }
        index = tempindex;
    }
    printf("%d\n", M);
    return 0;
}