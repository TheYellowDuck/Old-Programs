#include <stdio.h>
#include <stdlib.h>

int main() {
    int nl = 0;
    while (1) {
        char c;
        scanf("%c", &c);
        if (c == 10) break;
        if (c >= 'A' && c <= 'T') {
            if (nl) printf("\n");
            nl = 0;
            printf("%c", c);
        }
        else if (c == '+') printf(" tighten ");
        else if (c == '-') printf(" loosen ");
        else {
            printf("%c", c);
            nl = 1;
        }
    }
    printf("\n");
    return 0;
}