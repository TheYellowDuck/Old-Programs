#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int max(int a, int b) {
    if (a >= b) return a;
    return b;
}

// int mindex[100000], mnindex[100000];
long must[100000];
long mustnot[100000];

long hash(char string[11], char string2[11]) {
    long hash = 7;
    if (strcmp(string, string2) <= 0) {
        for (int i = 0; i < 10; i ++) {
            if (string[i] == 0) break;
            hash = hash * 31 + (string[i] - 'A' + 1);
        }
        hash = hash * 31 + 30;
        for (int i = 0; i < 10; i ++) {
            if (string2[i] == 0) break;
            hash = hash * 31 + (string2[i] - 'A' + 1);
        }
    }
    else {
        for (int i = 0; i < 10; i ++) {
            if (string2[i] == 0) break;
            hash = hash * 31 + (string2[i] - 'A' + 1);
        }
        hash = hash * 31 + 30;
        for (int i = 0; i < 10; i ++) {
            if (string[i] == 0) break;
            hash = hash * 31 + (string[i] - 'A' + 1);
        }
    }
    return hash;
}

int compare (const void * a, const void * b) {
   if( *(long*)a < *(long*)b)
        return -1;
    if( *(long*)a > *(long*)b)
        return 1;
    return 0;
}

int binarysearch(long *array, long H, int l, int r) {
    if (l > r) return 0;
    int m = l + (r - l) / 2;
    if (H == array[m]) 
        return 1;
    if (H < array[m])
        return binarysearch(array, H, l, m - 1);
    return binarysearch(array, H, m + 1, r);
}

int main() {
    int X;
    scanf("%d", &X);
    for (int i = 0; i < X; i ++) {
        char n1[11] = {0}, n2[11] = {0};
        scanf("%s %s", &n1, &n2); 
        must[i] = hash(n1, n2);
        // must[i][1] = hash(n2);
    }
    qsort(must, X, sizeof(long), compare);
    for (int loop = 0; loop < X; loop ++)
        printf("%d ", must[loop]);
    printf("\n");
    int Y;
    scanf("%d", &Y);
    for (int i = 0; i < Y; i ++) {
        char n1[11] = {0}, n2[11] = {0};
        scanf("%s %s", &n1, &n2); 
        mustnot[i] = hash(n1, n2);
        // mustnot[i][1] = hash(n2);
    }
    qsort(mustnot, Y, sizeof(long), compare);
    // for (int loop = 0; loop < Y; loop ++)
    //     printf("%d ", mustnot[loop]);
    // printf("\n");
    int G;
    scanf("%d", &G);
    int countX = 0,
    countY = 0;
    for (int i = 0; i < G; i ++) {
        char n1[11] = {0},
        n2[11] = {0},
        n3[11] = {0};
        scanf("%s %s %s", &n1, &n2, &n3);
        long h1 = hash(n1, n2), h2 = hash(n1, n3), h3 = hash(n2, n3);
        // printf("%d %d %d\n", h1, h2, h3);

        countX += binarysearch(must, h1, 0, X - 1) + binarysearch(must, h2, 0, X - 1) + binarysearch(must, h3, 0, X - 1);
        countY += binarysearch(mustnot, h1, 0, Y - 1) + binarysearch(mustnot, h2, 0, Y - 1) + binarysearch(mustnot, h3, 0, Y - 1);

        // int tempcountx = 0, tempcounty = 0, M = max(X, Y);
        // for (int j = 0; j < M; j ++) {
        //     if (tempcountx < 3 && j < X) {
        //         if (mindex[j] == 1) goto Xlabel;
        //         if (must[j] == h1 || must[j] == h2 || must[j] == h3) {
        //             if (must[j] == h1 || must[j] == h2 || must[j] == h3) {
        //                 // printf("%d %d %d %d %d\n", must[j][0], must[j][1], h1, h2, h3);
        //                 countX ++;
        //                 tempcountx ++;
        //                 mindex[j] = 1;
        //             }
        //         }
        //     }
        //     Xlabel:;
        //     if (tempcounty < 3 && j < Y) {
        //         if (mnindex[j] == 1) goto Ylabel;
        //         if (mustnot[j] == h1 || mustnot[j] == h2 || mustnot[j] == h3) {
        //             if (mustnot[j] == h1 || mustnot[j] == h2 || mustnot[j] == h3) {
        //                 // printf("%d %d %d %d %d\n", mustnot[j][0], mustnot[j][1], h1, h2, h3);
        //                 countY ++;
        //                 tempcounty ++;
        //                 mnindex[j] = 1;
        //             }
        //         }
        //     }
        //     Ylabel:;
        //     if (tempcountx == 3 && tempcounty == 3) break;
        // }
        printf("%d %d\n", countX, countY);
    }
    printf("%d\n", X - countX + countY);
    return 0;
}