#include <stdio.h>
#include <stdlib.h>

int main() {
    int cnt = 0, gold = 1;
    int N = 0;
    scanf("%d", &N);
    int score = 0;
    for (int i = 0; i < N * 2; i ++) {
        int in;
        scanf("%d", &in);
        if (i % 2) {
            score -= in * 3;
            if (score > 40) cnt ++;
            else gold = 0;
            score = 0;
        }
        else 
            score += in * 5;
    }
    printf("%d%c\n", cnt, gold ? '+' : '\0');
    return 0;
}