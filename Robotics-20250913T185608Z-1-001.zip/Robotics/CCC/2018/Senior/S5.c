#include <stdio.h>
#include <stdlib.h>

// #define MAX ((int) (1e9 / 2) + 1);

struct City {
    int id;
    City connection[100001];
    int put = 0;
}

struct Planet {
    City cities[100001];
    int put
}


long numSubTrees (int w) {
    if (trees[w] != 0) return trees[w];
    for (int i = 2; i <= w; i ++) {
        int r = w % i;
        int d = w / i;
        trees[w] += (r / d + 1) * numSubTrees (d);
        i += r / d;
    }
    return trees[w];
}

int main() {
    int N;
    scanf("%d", &N);
    trees[1] = 1;
    trees[2] = 1;
    printf("%ld\n", numSubTrees (N));
    // for (int i = 0; i < N; i ++) {
    //     printf("%d\n", trees[i]);
    // }
    return 0;
}