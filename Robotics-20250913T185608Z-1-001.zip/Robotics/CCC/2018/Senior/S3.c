#include <stdio.h>
#include <stdlib.h>

char map[100][100];
int time[100][100];

int N, M;

int queue[10001][2];
int front = 0, back = 0, itemcount = 0;
int null[2] = {-1, -1};
int cell[2];

int isEmpty () {
    return itemcount == 0;
}
void add (int a, int b) {
    if (a == -1 || b == -1) return;
    if (back == 10001) back = 0;
    queue[back][0] = a;
    queue[back ++][1] = b;
    itemcount ++;
    return;
}
int* peek () {
    if (front >= back) return null;
    return queue[front];
}
int* pop () {
    if (front >= back) return null;
    cell[0] = 0;
    cell[1] = 0;
    while (cell[0] == 0 && cell[1] == 0) {
        cell[0] = queue[front][0];
        cell[1] = queue[front ++][1];
        // printf("v%d %d\n", cell[0], cell[1]);
    }
    queue[front - 1][0] = 0;
    queue[front - 1][1] = 0;
    itemcount --;
    return cell;
}

void inCamera (int x, int y) {
    for (int i = x; i >= 0; i --) {
        if (map[i][y] == 'W') break;
        else if (map[i][y] == '.' || map[i][y] == 'S') time[i][y] = -1;
    }
    for (int i = x + 1; i < N; i ++) {
        if (map[i][y] == 'W') break;
        else if (map[i][y] == '.' || map[i][y] == 'S') time[i][y] = -1;
    }
    for (int j = y - 1; j >= 0; j --) {
        if (map[x][j] == 'W') break;
        else if (map[x][j] == '.' || map[x][j] == 'S') time[x][j] = -1;
    }
    for (int j = y + 1; j < M; j ++) {
        if (map[x][j] == 'W') break;
        else if (map[x][j] == '.' || map[x][j] == 'S') time[x][j] = -1;
    }
    return;
}

int neighbour[2];

void onConveyor (int x, int y, int t) {
    if (time[x][y] != 0) {
        neighbour[0] = -1;
        neighbour[1] = -1;
        return;
    }
    time[x][y] = t;
    if (map[x][y] == '.') {
        time[x][y] = t;
        neighbour[0] = x;
        neighbour[1] = y;
        return;
    }
    if (map[x][y] == 'U') {
        onConveyor (x - 1, y, t);
        return;
    }
    if (map[x][y] == 'D') {
        onConveyor (x + 1, y, t);
        return;
    }
    if (map[x][y] == 'L') {
        onConveyor (x, y - 1, t);
        return;
    }
    if (map[x][y] == 'R') {
        onConveyor (x, y + 1, t);
        return;
    }
    else {
        neighbour[0] = -1;
        neighbour[1] = -1;
        return;
    }
}

void addNeighbours (int x, int y) {
    int t = time[x][y] + 1;
    if (map[x - 1][y] != 'S' && map[x - 1][y] != 'W' && map[x - 1][y] != 'C' && time[x - 1][y] == 0) {
        onConveyor(x - 1, y, t);
        add(neighbour[0], neighbour[1]);
    }
    if (map[x + 1][y] != 'S' && map[x + 1][y] != 'W' && map[x + 1][y] != 'C' && time[x + 1][y] == 0) {
        onConveyor(x + 1, y, t);
        add(neighbour[0], neighbour[1]);
    }
    if (map[x][y - 1] != 'S' && map[x][y - 1] != 'W' && map[x][y - 1] != 'C' && time[x][y - 1] == 0) {
        onConveyor(x, y - 1, t);
        add(neighbour[0], neighbour[1]);
    }
    if (map[x][y + 1] != 'S' && map[x][y + 1] != 'W' && map[x][y + 1] != 'C' && time[x][y + 1] == 0) {
        onConveyor(x, y + 1, t);
        add(neighbour[0], neighbour[1]);
    }
}

int main() {
    scanf("%d %d\n", &N, &M);
    int Sx = -1, Sy = -1;
    for (int i = 0; i < N; i ++) {
        for (int j = 0; j < M; j ++) {
            char c;
            scanf("%c", &c);
            map[i][j] = c;
            if (c == 'S') {
                Sx = i;
                Sy = j;
                // map[i][j] = 'W';
            }
        }
        char plchld;
        scanf("%c", &plchld);
    }
    for (int i = 0; i < N; i ++) {
        for (int j = 0; j < M; j ++) {
            if (map[i][j] == 'C') inCamera(i, j);
        }
    }
    // printf("hehre\n");

    if (time[Sx][Sy] == -1) {
        for (int i = 0; i < N; i ++) {
            for (int j = 0; j < M; j ++) {
                if (map[i][j] == '.') printf("%d\n", -1);
            }
        }
        return 0;
    }
    // printf("%d %d\n", Sx, Sy);
    add(Sx, Sy);
    while (!isEmpty ()) {
        int* cell = pop();
        // printf("a%d %d\n", cell[0], cell[1]);
        addNeighbours (cell[0], cell[1]);
    }

    for (int i = 0; i < N; i ++) {
        for (int j = 0; j < M; j ++) {
            if (map[i][j] == '.') printf("%d\n", time[i][j] == 0 ? -1 : time[i][j]);
            // _sleep(1);
        }
    }

    return 0;
}