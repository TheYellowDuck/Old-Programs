#include <stdio.h>
#include <stdlib.h>

// #define MAX ((int) (1e9 / 2) + 1);

long trees[1000000001];

int main() {
    int N;
    scanf("%d", &N);
    trees[1] = 1;
    trees[2] = 1;
    for (int i = 3; i <= N; i ++) {
        
    }
    return 0;
}