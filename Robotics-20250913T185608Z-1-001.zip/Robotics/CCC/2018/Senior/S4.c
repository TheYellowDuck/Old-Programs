#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// #define MAX ((int) (1e9 / 2) + 1);

typedef struct {
    int key;
    long val;
} Pair;
Pair trees[100000];
int treecount = 0;

int binarysearch (int l, int r, int v) {
    if (l == r) return trees[l].key <= v ? l : -1;
    int m = l + (r - l) / 2;
    if (v < trees[m].key) return binarysearch (l, m, v);
    int ret = binarysearch (m + 1, r, v);
    return ret == -1 ? m : ret;
}

int comparator(const void *p, const void *q) 
{
    int l = ((Pair *)p)->key;
    int r = ((Pair *)q)->key; 
    return l - r;
}

long numSubTrees (int w) {
    Pair * exist = (Pair *) bsearch(&w, trees, treecount, sizeof(Pair), comparator);
    if (exist != NULL) return exist->val;
    long val = 0;
    for (int i = 2; i <= w; i ++) {
        int r = w % i;
        int d = w / i;
        val += (r / d + 1) * numSubTrees (d);
        i += r / d;
    }
    int inserti = binarysearch(0, treecount - 1, w) + 1;
    memmove(&trees[inserti + 1], &trees[inserti], (treecount - inserti) * sizeof(Pair));
    // for (int i = treecount; i > inserti; i --) {
    //     trees[i] = trees[i - 1];
    // }
    trees[inserti].key = w;
    trees[inserti].val = val;
    treecount ++;
    return val;
}

int main() {
    int N;
    scanf("%d", &N);
    trees[treecount].key = 1;
    trees[treecount ++].val = 1;
    trees[treecount].key = 2;
    trees[treecount ++].val = 1;
    printf("%ld\n", numSubTrees (N));
    // for (int i = 0; i < N; i ++) {
    //     printf("%d\n", trees[i]);
    // }
    return 0;
}