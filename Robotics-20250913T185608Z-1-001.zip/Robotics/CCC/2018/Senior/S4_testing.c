#include <stdio.h>
#include <stdlib.h>



int count = 0;

int numSubTrees (int w) {

    for (int i = 2; i <= w; i ++) {
        trees[w] += numSubTrees (w / i);
    }
    return trees[w];
}

int main() {
    int N = 1e9;
    printf("%d\n", numSubTrees (N));
    return 0;
}