#include <stdio.h>
#include <stdlib.h>

int min (int a, int b) {
    if (a <= b) return a;
    return b;
}

int pages[10001];
int connections[20001];
int indexp = 0;

int time[10001];
int count = 0, minT = 50000;

int queue[10001];
int front = 0, back = 0, itemcount = 0;

int isEmpty () {
    return itemcount == 0;
}
int add (int a) {
    if (back == 10001) back = 0;
    queue[back ++] = a;
    itemcount ++;
    return a;
}
int peek () {
    if (front >= back) return -1;
    return queue[front];
}
int pop () {
    if (front >= back) return -1;
    int v = 0;
    while (v == 0) {
        v = queue[front ++];
    }
    queue[front - 1] = 0;
    itemcount --;
    return v;
}

int main() {
    int N;
    scanf("%d", &N);
    for (int i = 1; i <= N; i ++) {
        int M;
        scanf("%d", &M);
        pages[i + 1] = 1 + M + pages[i];
        connections[indexp ++] = M;
        for (int j = 0; j < M; j ++) {
            int page;
            scanf("%d", &page);
            connections[indexp ++] = page;
        }
    }

    add(1);
    count ++;
    time[1] = 1;
    while (!isEmpty ()) {
        int page = pop ();
        int pagei = pages[page];
        if (connections[pagei] == 0) 
            minT = min (minT, time[page]);
        for (int i = 1; i <= connections[pagei]; i ++) {
            int v = connections[pagei + i];
            if (time[v] == 0) {
                count ++;
                time[v] = time[page] + 1;
                add(v);
            }
            else if (time[v] > time[page] + 1) {
                time[v] = time[page] + 1;
                add(v);
            }
        }
    }

    printf("%c\n", count == N ? 'Y' : 'N');
    printf("%d\n", minT);

    return 0;
}