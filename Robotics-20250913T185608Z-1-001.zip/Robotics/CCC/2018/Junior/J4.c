#include <stdio.h>
#include <stdlib.h>

int flowers[100][100];

int main() {
    int N;
    scanf("%d", &N);
    int H = 0, V = 0;

    for (int i = 0; i < N; i ++) {
        for (int j = 0; j < N; j ++) {
            int v;
            scanf("%d", &v);
            flowers[i][j] = v;
            if (j != 0 && v > flowers[i][j - 1]) H = 1;
            if (j != 0 && v < flowers[i][j - 1]) H = -1;
            if (i != 0 && v > flowers[i - 1][j]) V = 1;
            if (i != 0 && v < flowers[i - 1][j]) V = -1;
        }
    }
    if (H == 1 && V == 1) {
        for (int i = 0; i < N; i ++) {
            for (int j = 0; j < N; j ++) 
                printf("%d ", flowers[i][j]);
            printf("\n");
        }
    }
    else if (H == 1 && V == -1) {
        for (int j = 0; j < N; j ++) {
            for (int i = N - 1; i >= 0; i --) 
                printf("%d ", flowers[i][j]);
            printf("\n");
        }
    }
    else if (H == -1 && V == 1) {
        for (int j = N - 1; j >= 0; j --) {
            for (int i = 0; i < N; i ++) 
                printf("%d ", flowers[i][j]);
            printf("\n");
        }
    }
    else {
        for (int i = N - 1; i >= 0; i --) {
            for (int j = N - 1; j >= 0; j --) 
                printf("%d ", flowers[i][j]);
            printf("\n");
        }
    }
    return 0;
}