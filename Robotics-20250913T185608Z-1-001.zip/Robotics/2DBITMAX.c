// 1-indexed

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX 5001

int A[MAX];
int BIT1[MAX]; // < N - root
int BIT2[MAX]; // 0 - root

int N, M;

static inline int getindex (int x, int y) {
    return x * N + y;
}

static inline void update (int n, int v) {
    int old = A[n];
    A[n] = v;

    int i = n; 
    while (i <= N) {
        if (v < BIT1[i]) {
            if (old == BIT1[i]) {
                v = v >= A[i] ? v : A[i];
                for (int j = 1; j < (i & -i); j << 1) 
                    v = v >= BIT1[i - j] ? v : BIT1[i - j];
            }
            else goto endBIT1;
        }
        if (v == BIT1[i]) break;
        BIT1[i] = v;
        i += (i & -i); 
    }
    endBIT1:;

    i = n; 
    while (i > 0) {
        if (v < BIT2[i]) {
            if (old == BIT2[i]) {
                v = v >= A[i] ? v : A[i];
                for (int j = 1; j < (i & -i); j << 1) 
                    v = v >= BIT2[i + j] ? v : BIT2[i + j];
            }
            else goto endBIT2;
        }
        if (v == BIT2[i]) break;
        BIT2[i] = v;
        i -= (i & -i); 
    }
    endBIT2:;

    for (int ii = 1; ii <= N; ii ++) 
        printf("%d ", A[ii]);
    printf("\n");
    for (int ii = 1; ii <= N; ii ++) 
        printf("%d ", BIT1[ii]);
    printf("\n");
    for (int ii = 1; ii <= N; ii ++) 
        printf("%d ", BIT2[ii]);
    printf("\n\n");
}

static inline int query (int a, int b) {
    int max = INT_MIN;
    
    int i = a;
    while (i + (i & -i) <= b) {
        max = max >= BIT2[i] ? max : BIT2[i];
        i += (i & -i);
    }

    i = b;
    while (i - (i & -i) >= a) {
        max = max >= BIT1[i] ? max : BIT1[i];
        i -= (i & -i);
    }

    max = max >= A[i] ? max : A[i];

    return max;
}

int main() {
    scanf("%d", &N);
    for (int i = 1; i <= N; i ++) {
        scanf("%d", &A[i]);
        update(i, A[i]);
    }
    scanf("%d", &M);
    for (int i = 1; i <= M; i ++) {
        int Q, X, Y;
        scanf ("%d %d %d", &Q, &X, &Y);
        if (Q) printf("%d\n", query (X, Y));
        else update (X, Y);
    }
    return 0;
}