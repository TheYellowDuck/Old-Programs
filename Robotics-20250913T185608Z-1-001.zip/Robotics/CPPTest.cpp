#include <iostream>
// // #include <bits/stdc++.h>
#include <unordered_set>
#include <cstdio>
using namespace std;
// #include <stdlib.h>

unordered_set <string> S;
// char N[200001];
char H[200001];
int N[26];
int HC[26];
// int count = 0;

int main() {
    // printf("hi\n");
    int Nlength = 0;
    while (1) {
        char s;
        scanf("%c", &s);
        if (s == '\n') break;
        N[s - 'a'] ++;
        Nlength ++;
    }
    
    // for (int i = 0; i < 26; i ++) printf("%c: %d\n", i + 'a', N[i]);

    scanf("%s", H);
    
    // printf("%s\n", H);

    for (int i = 0; i < Nlength; i ++) {
        char s = H[i];
        if (s == '\0') {
            printf("0\n");
            return 0;
        }
        HC[s - 'a'] ++;
    }
    // for (int i = 0; i < 26; i ++) printf("%c: %d\n", i + 'a', HC[i]);
    // printf("here\n");
    // int Hlength = 0;
    for (int i = Nlength; 1; i ++) {
        // char s;
        // scanf("%c", &s);
        // Hlength ++;
        int match = 1;
        for (int j = 0; j < 26; j ++) {
            if (N[j] != HC[j]) {
                match = 0;
                break;
            }
        }
        if (match) {
            // string s;
            // copy(&H[i - Nlength], &H[i], &s);
            // S.insert(s);
            S.insert(string(&H[i - Nlength], &H[i]));
        }
        if (H[i] == '\0') break;
        HC[H[i - Nlength] - 'a'] --;
        HC[H[i] - 'a'] ++; 
        // for (int i = 0; i < 26; i ++) printf("%c: %d\n", i + 'a', HC[i]);
    }
    // printf("%d\n", count);
    printf("%ld\n", S.size());
    return 0;
}