#include <iostream>
#include <stdlib.h>
using namespace std;

int main() {
    cout << "Hi\n";
    return 0;
}