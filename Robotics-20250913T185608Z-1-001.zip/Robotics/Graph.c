#include <stdio.h>
#include <stdlib.h>

#define MAX 10000

typedef struct {
    int id;
    int v;
    struct AdjNode* prev;
    struct AdjNode* next;
} AdjNode;

typedef struct {
    int id;
    int v;
    int size;
    struct AdjNode* head;
    struct AdjNode* tail;
} AdjList;

typedef struct {
    int nodecount;
    int edgecount;
    struct AdjList* nodes;
} Graph;

static inline AdjNode* newNode(int id) {
    AdjNode* N = (AdjNode*) malloc(sizeof(AdjNode));
    N->id = id;
    N->v = id;
    N->prev = NULL;
    N->next = NULL;
    return N;
}
static inline AdjList* newList(int id) {
    AdjList* L = (AdjList*) malloc(sizeof(AdjList));
    L->id = id;
    L->v = id;
    L->size = 0;
    L->head = NULL;
    L->tail = NULL;
    return L;
}
static inline Graph* newGraph(int N, int M) {
    Graph* G = (Graph*) malloc(sizeof(Graph));
    G->nodecount = N;
    G->edgecount = M;
    G->nodes = (struct AdjList*) malloc(N *sizeof(AdjList));
    for (int i = 0; i <= N; i ++) 
        G->nodes[i] = newList(i);
    return G;
}

static inline void add(Graph* G, int a, int b) {
    AdjList* L = G->nodes[a];
    L.id = a;
    AdjNode* n = newNode(b);
    if (L->head == NULL) {
        L->head = &n;
        L->tail = L->head;
    }
    else {
        L->tail->next = &n;
        n.prev = L->tail;
        L->tail = &n;
    }
    L->size ++;
}

static inline void print(Graph* G) {
    for (int i = 0; i <= G->nodecount; i ++) {
        AdjList* L = G->nodes[i];
        printf("%d: ", L->id);
        AdjNode* N = L->head;
        for (int j = 0; j < L->size; j ++) {
            printf("%d, ", N->id);
            N = N->next;
        }
        printf("\n");
    }
}

int main() {
    int N, M;
    scanf("%d %d", &N, &M);
    Graph* G = newGraph(N, M);
    for (int i = 0; i < M; i ++) {
        int a, b;
        scanf("%d %d", &a, &b);
        add(G, a, b);
    }
    print(G);
    return 0;
}