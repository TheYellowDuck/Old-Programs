#include <stdio.h>
int main() {
    int x;
    scanf("%d", &x);
    x += 100;
    printf("%d\n", x);
    return 0;
}