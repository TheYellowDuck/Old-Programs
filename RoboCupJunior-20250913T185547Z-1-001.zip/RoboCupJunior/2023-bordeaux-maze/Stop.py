# Untitled - By: gzhan - Fri May 26 2023
from pyb2 import *
motor = SServo(1)
motor.set_speeds([0, 0, 0, 0])
