package Rubix_Cube;

public class Box {
	
	PVector pos;
	
	Box(float x, float y, float z, float len)

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
