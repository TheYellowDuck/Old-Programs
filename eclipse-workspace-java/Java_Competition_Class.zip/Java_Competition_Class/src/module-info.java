module Java_Competition_Class {
	requires java.desktop;
}