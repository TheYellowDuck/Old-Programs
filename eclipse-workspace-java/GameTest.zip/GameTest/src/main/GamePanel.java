package main;

import javax.swing.JPanel;

public class GamePanel extends JPanel {

	

}